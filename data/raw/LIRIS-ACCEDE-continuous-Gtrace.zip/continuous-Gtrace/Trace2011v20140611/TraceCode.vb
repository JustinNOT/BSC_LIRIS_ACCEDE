﻿Option Explicit On 'require variable declaration

Imports System.IO

Public Structure Rating
    Public Description As String
    Public JPGFile As String
    Public JPG As Image
    Public minRange As Integer
    Public maxRange As Integer
    Public circleColourLeft As Color
    Public circleColourRight As Color
    Public circleColourNeutral As Color
    Public neutralColour As Boolean
    Public rated As Boolean
End Structure

Public Structure PlayList
    Public item As String
    Public folder As String
    Public playCount As Integer 'NOT USED
    Public dataCollected As Boolean 'NOT USED
End Structure


Module TraceCode

    'These define the rating
    Public Const maxRatingLabels As Integer = 10
    Public Const maxRatings As Integer = 500

    Public ratingInfo(maxRatings) As Rating
    Public tempRatingInfo As Rating
    Public ratingPlusInfo(maxRatings, 4) As Rating
    Public ratingPlusSelected(maxRatings) As Rating
    Public ratingCount As Integer
    Public rpSelectedCount As Integer
    Public ratingSelected As Boolean

    Public plusOption As Integer
    Public Const plusOptionOff = 0
    Public Const plusOptionNoRatings = 1
    Public Const plusOptionWithRatings = 2

    Public strRatingPlusDataFile As String

    Public ratingFile As String
    Public circleColour(3) As Color
    Public neutralColour As Boolean
    Public nLabel As Integer
    Public ratingJPG As String
    Public ratingDescription As String
    Public ratingImage As Image

    Public sr As StreamReader
    Public sw As StreamWriter

    'PlayLists
    Public Const maxPlaylistItems As Integer = 100
    ' Public nPLItems As Integer
    Public playlistItems(maxPlaylistItems) As PlayList
    Public tempPlayListItem As PlayList
    Public mediaFolder As String
    Public mediaCount As Integer

    Public outfile As System.IO.StreamWriter

    Public homeFolder As String
    Public ratingsFolder As String
    Public dataFolder As String
    Public plusFolder As String

    Public saveData As Boolean
    Public panelMouseDown As Boolean
    Public dontTriggerIndexChange As Boolean

    Public displayState As Integer
    ' Public clipCount As Integer

    'WMP
    Public WMPcontrols1 As WMPLib.IWMPControls = FrmCombined.AxWMP.Ctlcontrols  ' related to the Windows Media Player in the FrmCombined
    Public WMPcontrols2 As WMPLib.IWMPControls2 = FrmCombined.AxWMP.Ctlcontrols
    Public WMPcontrols3 As WMPLib.IWMPControls3 = FrmCombined.AxWMP.Ctlcontrols

    Public ticks1, ticks2, interlong, msec As Long

    Public blackPen As New Pen(Color.FromArgb(255, 0, 0, 0), 3)
    Public rectangleLeft As Single
    Public rectangleRight As Single
    Public rectangleWidth As Single
    Public rectangleHeight As Single
    Public rectangleTop As Single
    Public rectangleBottom As Single

    'Create buffer for graphics
    Public gPanel As Graphics
    Public BufferedContext As BufferedGraphicsContext
    Public doubleBuffer As BufferedGraphics

    'ORIGINAL FeelTrace
    Public intCC As Integer
    Public clipselected As Boolean 'there is a clip
    Public sbcount As Integer 'number of space key strikes
    Public MPlayerLoaded As Boolean     'clip data completely loaded into MediaPlayer control

    Public Const ncirc = 18 '20               'no. of individual circles (from RC code: don't change)
    Public Const radfact = 5 '15             'factor to determine radius of largest circle
    Public Const circrad = ncirc * radfact          'radius of largest circle

    'Public cursorx&, cursory&          'current Cursor x, y
    'Public mousex&, mousey&            'current mouse x, y
    ' Public MouseDown$
    Public Start&                       'start time
    'Public choosemode As Boolean 'whether to choose display mode for every clip
    'Public runmode%, lastrunmode%
    Public cx!, cy!, r!              'centre and radius of circle
    Public xL!, yL!, tL!             'last position of cursor circle, time of last record
    Public circrecords(ncirc, 5)     'Two dimentional array

    Public intMBwidth As Integer, intMBheight As Integer, intMBleft As Integer, intMBtop As Integer

    Public coord As Single
    Public minRange As Integer
    Public maxRange As Integer
    Public coordRange As Integer

    Public numMousePanelDown As Integer = 0
    Public time As Single
    Public lTime As Single
    Public dataNumber As Integer   'used to record a certain number of data
    Public isReadyToStart As Boolean = False
    Public isEnd As Boolean = False    'if all the videos are played
    Public numFilmPlayed As Integer = 0


    Sub RunRating()

        'Dim intCC As Integer
        Dim tempString As String

        'On Error GoTo CancelHandler
        FrmCombined.lblVideoName.Text = IO.Path.GetFileName(FrmCombined.AxWMP.URL)
        FrmCombined.lblVideoName.Left = (FrmCombined.Width - FrmCombined.lblVideoName.Width) / 2
        FrmCombined.lblVideoName.Top = 5
        'FrmCombined.lblVideoName.Show()  Uncomment this line to show the title of the playing video


        'record the data from the beginning
        panelMouseDown = True


        If saveData = True Then

            Dim strOutname As String
            Dim filenameOnly As String
            Dim basenameOnly As String

            'strOutname = mediaFolder & "\" & FrmCombined.txtID.Text & FrmCombined.AxWMP.URL & ".txt"
            filenameOnly = IO.Path.GetFileName(FrmCombined.AxWMP.URL)
            basenameOnly = Microsoft.VisualBasic.Left(filenameOnly, Microsoft.VisualBasic.Len(filenameOnly) - 4)
            strOutname = dataFolder & "\" & basenameOnly & "_" & ratingDescription & "_" & FrmStartup.txtID.Text & ".txt"
            outfile = My.Computer.FileSystem.OpenTextFileWriter(strOutname, True)
            outfile.WriteLine(Date.Now)  'Date of the 
            outfile.WriteLine(FrmStartup.txtID.Text)
            outfile.WriteLine(FrmCombined.AxWMP.URL)  ' URL of the video to rate
            outfile.WriteLine(ratingJPG)  'The scale picture used for rating
            outfile.WriteLine(ratingDescription) 'The name of the rating scale
            outfile.WriteLine(minRange & "," & maxRange) 'The value range of the scale
            outfile.Write(circleColour(1).R & "," & circleColour(1).G & "," & circleColour(1).B & vbTab)  '
            outfile.Write(circleColour(2).R & "," & circleColour(2).G & "," & circleColour(2).B & vbTab)
            If neutralColour = True Then
                outfile.WriteLine(circleColour(3).R & "," & circleColour(3).G & "," & circleColour(3).B)
            Else
                outfile.WriteLine()
            End If
            outfile.WriteLine(plusOption)

        End If


        'Set position and size of trace circle - position in centre with adjustment for size of circle
        cx! = rectangleLeft + rectangleWidth / 2 '- circrad / 2
        cy! = rectangleTop + rectangleHeight / 2

        'r! needs to be width of rectangle
        r! = rectangleWidth / 2


        For intCC As Integer = 1 To ncirc
            circrecords(intCC, 1) = Cursor.Position.X - FrmCombined.MousePanel.Left - FrmCombined.Left - cx!
            ' circrecords(intCC, 1) = 0
            ' circrecords(intCC, 1) = cx!
            circrecords(intCC, 2) = cy!
            circrecords(intCC, 3) = 255.0!
            circrecords(intCC, 4) = 255.0!
            circrecords(intCC, 5) = 255.0!
        Next
        'Initialise xL, yL
        xL! = 0 - circrad / 2 'cursorPosition.X - cx!
        yL! = 0.0! ' + rectangleHeight / 2 ' adjust to centre the circle in the rectangle

        'Rewind in case has been previously played
        If mediaCount = 1 Then   'we rerate only one video at a time
            WMPcontrols1.currentPosition = FrmCombined.tbStartTime.Text

        Else
            WMPcontrols1.currentPosition = 0
        End If

        WMPcontrols1.play()

        Cursor.Hide()  'hide the mouse cursor on the screen

        Start& = Date.Now.Ticks
        tL! = 0
        msec = 250
        ticks1 = Date.Now.Ticks
        Do
            Application.DoEvents()
            ticks2 = Date.Now.Ticks
            interlong = (ticks2 - ticks1) * 0.0001
        Loop Until interlong >= msec 'debounce

        'Center the position before the rating procedure
        Cursor.Position = New Point(FrmCombined.MousePanel.Left + FrmCombined.Left + FrmCombined.MousePanel.Width / 2, FrmCombined.MousePanel.Top + FrmCombined.Top + FrmCombined.MousePanel.Height / 2)

        Do
            Application.DoEvents()
            ManageMouse()
        Loop Until WMPcontrols1.currentPosition > FrmCombined.AxWMP.currentMedia.duration - 0.001   'the video playing finishes,here 0.001 seconds in advance because there is often a problem of the stop of the iteration
        'FrmCombined.AxWMP.status = "Stopped"
        'FrmCombined.AxWMP.currentMedia.duration = WMPcontrols1.currentPosition
        ' 'WMPcontrols1.currentPosition = 0   'the video playing finishes

        numFilmPlayed = numFilmPlayed + 1

        FrmCombined.AxWMP.Hide() ' video ends so hide the player

        'Rating finished so stop video and show cursor
        WMPcontrols1.stop()
        Cursor.Show()

        'Rating is finished
        If saveData Then outfile.Close()

        sbcount = 0 'reset

        'Loop until turn off video
        Do
            Application.DoEvents()
        Loop Until WMPcontrols1.currentPosition = 0

        'clipCount = clipCount + 1

        'What happens next depends on plusOption
        If plusOption = plusOptionOff Then   'no plus option - just a std run. If PlayList, select next clip. If not, select next rating.
            'If playlist - go to next media but keep rating the same.
            If FrmCombined.cbRunAsPlayList.Checked = True Then   'move to next media item
                'Make sure our item is not the last one on the list.
                If FrmCombined.lbListPlaylist.SelectedIndex < FrmCombined.lbListPlaylist.Items.Count - 1 Then
                    FrmCombined.lbListPlaylist.SelectedIndex = FrmCombined.lbListPlaylist.SelectedIndex + 1


                    FrmCombined.lblVideoName.Hide()


                    WMPcontrols1.pause()
                    WMPcontrols1.currentPosition = 0 'rewind to start
                    clipselected = True

                    FrmCombined.lblNotice.Left = (FrmCombined.Width - FrmCombined.lblNotice.Width) / 2
                    FrmCombined.lblNotice.Top = 230
                    FrmCombined.lblNotice.Show()  'we must reconfigure the positon of the lblNotice before each show() cause the size of the label changes with its content
                    sbcount = 0


                Else
                    'MsgBox("PlayList is finished, please click the ""close"" button bleow on the right then click EXIT")
                    FrmCombined.AxWMP.Hide()
                    FrmCombined.lblNotice.Text = "END of the ratings " & vbCrLf & "Thank you very much! :-)" & vbCrLf & "Please call the administrator"
                    FrmCombined.lblNotice.Left = (FrmCombined.Width - FrmCombined.lblNotice.Width) / 2
                    FrmCombined.lblNotice.Top = 230
                    FrmCombined.lblNotice.Show()
                    isEnd = True

                End If
                'Else  'If NOT playlist, go to next rating if poss
                'If FrmCombined.lbRatings.SelectedIndex < FrmCombined.lbRatings.Items.Count - 1 Then
                'FrmCombined.lbRatings.SelectedIndex = FrmCombined.lbRatings.SelectedIndex + 1
                'End If
            End If
            're-select video
            'FrmCombined.AxWMP.URL = mediaFolder & "\" & FrmCombined.lbListPlaylist.SelectedItem.ToString
            FrmCombined.AxWMP.URL = playlistItems(FrmCombined.lbListPlaylist.SelectedIndex + 1).item
            Do
                Application.DoEvents()
            Loop Until FrmCombined.AxWMP.playState = WMPLib.WMPPlayState.wmppsPlaying '"Playing"
            WMPcontrols1.pause()
            WMPcontrols1.currentPosition = 0 'rewind to start
            clipselected = True
        ElseIf plusOption = plusOptionNoRatings Then '1st time through - show RatingPlus window
            FrmRatingPlus.Show()
        ElseIf plusOption = plusOptionWithRatings Then
            'record rating
            ratingPlusSelected(FrmCombined.lbRatings.SelectedIndex + 1).rated = True
            tempString = FrmCombined.lbRatings.Items(FrmCombined.lbRatings.SelectedIndex)
            FrmCombined.lbRatings.Items(FrmCombined.lbRatings.SelectedIndex) = "RATED " & tempString
            'Move to next rating if possible
            If FrmCombined.lbRatings.SelectedIndex < FrmCombined.lbRatings.Items.Count - 1 Then
                FrmCombined.lbRatings.SelectedIndex = FrmCombined.lbRatings.SelectedIndex + 1
            End If

            're-select same video
            'FrmCombined.AxWMP.URL = mediaFolder & "\" & FrmCombined.lbListPlaylist.SelectedItem.ToString
            FrmCombined.AxWMP.URL = playlistItems(FrmCombined.lbListPlaylist.SelectedIndex + 1).item
            Do
                Application.DoEvents()
            Loop Until FrmCombined.AxWMP.playState = WMPLib.WMPPlayState.wmppsPlaying '"Playing"
            WMPcontrols1.pause()
            WMPcontrols1.currentPosition = 0 'rewind to start
            clipselected = True
        End If

    End Sub


    Sub ManageMouse()

        

        Dim videoDuration As Double

        Dim circlePen As Pen
        Dim circleBrush As Brush

        Dim xR!, yR!, rnorm!, curr_rad%
        Dim timeM! 'only needed for external videos (clipselected = False)
        Dim blue%, green%, red%
        Dim i
        'cursorx&, cursory& are pointer position.

        Try
            videoDuration = FrmCombined.AxWMP.currentMedia.duration

        Catch ex As Exception

        End Try


        'FrmCombined.MousePanel.Focus()

        'convert cursor.position in screen coordinates to mousepanel control coordinates
        Dim cursorPosition As Point
        cursorPosition.X = Cursor.Position.X - FrmCombined.MousePanel.Left - FrmCombined.Left
        cursorPosition.Y = Cursor.Position.Y - FrmCombined.MousePanel.Top - FrmCombined.Top

        xR! = cursorPosition.X - cx!
        'yR! = cy! - cursorPosition.Y


        timeM! = (Date.Now.Ticks - Start&) / 10000000 'convert to seconds
        'Debug.Print(timeM! & " " & cx! & " " & cy! & " " & cursorPosition.X & " " & cursorPosition.Y & " " & xR! & " " & yR!)

        yR! = 0.0! '+ rectangleHeight / 2 ' adjust to centre the circle in the rectangle
        If xR! > r! Then xR! = r!
        If xR! < -r! Then xR! = -r!

        'Now convert to required range
        'coord converts xr/r to value from 0 -> 1
        coord = (1 + (xR! / r!)) / 2
        'now convert that to range in rating file
        coord = minRange + coord * coordRange
        Debug.WriteLine(WMPcontrols1.currentPosition & vbTab & CStr(xR! / r!) & vbTab & coord)

        If saveData = True And panelMouseDown = True Then ' write the rating record into a file
            If WMPcontrols1.currentPosition <> 0 Then
                dataNumber = dataNumber + 1
                time = CSng(WMPcontrols1.currentPosition)
                time = time.ToString("F2")
                If dataNumber = 1 Then
                    lTime = time
                    outfile.WriteLine(time & vbTab & CStr(coord))
                    FrmCombined.lblTime.Text = "Time: " & CInt(WMPcontrols1.currentPosition) & " / " & CInt(videoDuration) 'Time lable
                ElseIf time <> lTime Then
                    lTime = time
                    outfile.WriteLine(time & vbTab & CStr(coord))
                    FrmCombined.lblTime.Text = "Time: " & CInt(WMPcontrols1.currentPosition) & " / " & CInt(videoDuration)
                End If
            End If
        ElseIf saveData = True And panelMouseDown = False Then 'when video is playing but panelMouseDown = False, do nothing, stop recording

            'in this version of programme, the play of the video and the panelMouseDown are related, in fact, panelMouseDown control the play/pause.

            'If WMPcontrols1.currentPosition <> 0 Then
            'outfile.WriteLine(WMPcontrols1.currentPosition & vbTab & "N/A")
            'FrmCombined.lblTime.Text = CInt(WMPcontrols1.currentPosition) & " / " & CInt(videoDuration)
            'End If
        End If

        'Code for calculating "distance" between any 2 colours
        'LH colour is index (1), RH colour is index (2), neutral colour is index (3) 
        If neutralColour = False Then  'interpolate between L and R
            rnorm! = 0.5 + (xR! / r!) / 2  'Make 0 = LHS, 1 = RHS
            'Debug.Print(rnorm! * (circleColour(2).R - circleColour(1).R))
            red% = CInt(circleColour(1).R + rnorm! * (CSng(circleColour(2).R) - CSng(circleColour(1).R)))
            green% = CInt(circleColour(1).G + rnorm! * (CSng(circleColour(2).G) - CSng(circleColour(1).G)))
            blue% = CInt(circleColour(1).B + rnorm! * (CSng(circleColour(2).B) - CSng(circleColour(1).B)))
            'Debug.Print(play & " " & rnorm! & " " & blue% & " " & green% & " " & red% & " " & WMPcontrols1.currentPosition & vbTab & CStr(xR! / r!))
        ElseIf neutralColour = True Then 'interpolate from L to Centre and then from Centre to Right
            If xR! < 0 Then
                rnorm! = 1 + (xR! / r!) 'Make 0 = LHS, 1 = centre
                red% = CInt(circleColour(1).R + rnorm! * (CSng(circleColour(3).R) - CSng(circleColour(1).R)))
                green% = CInt(circleColour(1).G + rnorm! * (CSng(circleColour(3).G) - CSng(circleColour(1).G)))
                blue% = CInt(circleColour(1).B + rnorm! * (CSng(circleColour(3).B) - CSng(circleColour(1).B)))
            ElseIf xR! > 0 Then
                rnorm! = (xR! / r!) 'Make 0 = centre, 1 = RHS
                red% = CInt(circleColour(3).R + rnorm! * (CSng(circleColour(2).R) - CSng(circleColour(3).R)))
                green% = CInt(circleColour(3).G + rnorm! * (CSng(circleColour(2).G) - CSng(circleColour(3).G)))
                blue% = CInt(circleColour(3).B + rnorm! * (CSng(circleColour(2).B) - CSng(circleColour(3).B)))
            ElseIf xR! = 0 Then
                red% = CInt(circleColour(3).R)
                green% = CInt(circleColour(3).G)
                blue% = CInt(circleColour(3).B)
            End If
        End If

        'REDRAW BACKGROUND IMAGE
        'gPanel.DrawRectangle(blackPen, rectangleLeft, rectangleTop, rectangleWidth, rectangleHeight)
        Try
            doubleBuffer.Graphics.Clear(Color.White)

        Catch ex As Exception

        End Try


        doubleBuffer.Graphics.DrawImage(ratingImage, 0, 0)
        ' Dim RatingImage As Image = Image.FromFile(ratingJPG)
        FrmCombined.MousePanel.BackgroundImage = ratingImage
        FrmCombined.MousePanel.BackgroundImageLayout = ImageLayout.None
        ' doubleBuffer.Graphics.DrawRectangle(blackPen, rectangleLeft, rectangleTop, rectangleWidth, rectangleHeight)

        'NOW DRAW NEW POSITION IN RGB
        'Debug.Print(panelMouseDown)
        circleBrush = New SolidBrush(Color.FromArgb(255, red%, green%, blue%))
        circlePen = New Pen(Color.FromArgb(255, red%, green%, blue%), 1)  'thickness 1
        If panelMouseDown = True Then
            doubleBuffer.Graphics.FillEllipse(circleBrush, xR! + cx! - CSng(ncirc * radfact) / 2, rectangleTop + (rectangleHeight - ncirc * radfact) / 2, ncirc * radfact, ncirc * radfact)
        ElseIf panelMouseDown = False Then
            doubleBuffer.Graphics.DrawEllipse(circlePen, xR! + cx! - CSng(ncirc * radfact) / 2, rectangleTop + (rectangleHeight - ncirc * radfact) / 2, ncirc * radfact, ncirc * radfact)
        End If

        xL! = xR!
        yL! = yR!

        'CircArray
        If ((timeM! - tL!) > (1 / ncirc)) Then
            'test means tail represents a second's worth
            'draw over end of tail
            xL! = circrecords(intCC, 1)
            yL! = circrecords(intCC, 2)
            tL! = timeM!
            intCC = ncirc

            'move circle records down the tail
            For intCC As Integer = ncirc - 1 To 1 Step -1
                For i = 1 To 5
                    circrecords(intCC + 1, i) = circrecords(intCC, i)
                Next i
            Next intCC

            'introduce new top
            circrecords(1, 1) = xR!
            circrecords(1, 2) = yR!
            circrecords(1, 3) = blue%
            circrecords(1, 4) = green%
            circrecords(1, 5) = red%
            xL! = circrecords(1, 1)
            yL! = circrecords(1, 2)

            'draw new tail
            For intCC As Integer = ncirc - 1 To 1 Step -1
                xR! = circrecords(intCC, 1)
                yR! = circrecords(intCC, 2)

                curr_rad% = (ncirc - intCC - 1) * radfact
                circleBrush = New SolidBrush(Color.FromArgb(255, 255, 255, 255))
                circlePen = New Pen(Color.FromArgb(255, 255, 255, 255), 1)  'thickness 2
                blue% = circrecords(intCC, 3)
                green% = circrecords(intCC, 4)
                red% = circrecords(intCC, 5)

                '  Debug.Print(timeM! & " " & cx! & " " & cy! & " " & cursorPosition.X & " " & cursorPosition.Y & " " & xR! & " " & yR! & " " & (1 / ncirc) & " " & (ncirc - intCC + 1) * radfact & " " & curr_rad%)

                'DRAW BLACK OUTLINE OF TAIL CIRCLES
                circlePen = New Pen(Color.FromArgb(255, 0, 0, 0), 2)  'thickness 2
                doubleBuffer.Graphics.DrawEllipse(circlePen, xR! + cx! - CSng(curr_rad% / 2), rectangleTop + (rectangleHeight - curr_rad%) / 2, curr_rad%, curr_rad%)
                ' gPanel.DrawEllipse(circlePen, xR! + cx! + curr_rad%, cy! + CSng(curr_rad% / 2), curr_rad%, curr_rad%)

                'MS - FILL TAIL CIRCLE WITH COLOUR
                circleBrush = New SolidBrush(Color.FromArgb(255, red%, green%, blue%))
                doubleBuffer.Graphics.FillEllipse(circleBrush, xR! + cx! - CSng(curr_rad% / 2), rectangleTop + (rectangleHeight - curr_rad%) / 2, curr_rad%, curr_rad%)

                'IF MOUSE NOT DOWN THEN INNER PART OF TAIL CIRCLES SHOULD BE FILLED WITH WHITE
                If panelMouseDown = False Then
                    'MS - curr_rad% = curr_rad% - 60
                    curr_rad% = curr_rad% * 0.6
                    If curr_rad% < 1 Then curr_rad% = 1
                    circleBrush = New SolidBrush(Color.FromArgb(255, 255, 255, 255))
                    doubleBuffer.Graphics.FillEllipse(circleBrush, xR! + cx! - CSng(curr_rad% / 2), rectangleTop + (rectangleHeight - curr_rad%) / 2, curr_rad%, curr_rad%)
                End If

            Next intCC
            doubleBuffer.Render()
        End If 'finish time-dependent update of tail

    End Sub


    Sub PlayMedia(ByVal index As Integer)

        'MsgBox(mediaFolder & "\" & playlistItems(Me.lbListPlaylist.SelectedIndex + 1).item)
        Try
            'FrmCombined.AxWMP.URL = mediaFolder & "\" & FrmCombined.lbListPlaylist.SelectedItem.ToString
            FrmCombined.AxWMP.URL = playlistItems(index+ 1).item
        Catch Ex As Exception
            MessageBox.Show("Cannot read file from disk. Original error: " & Ex.Message)
        End Try
        WMPcontrols1.play()

        Do
            'Debug.Print(FrmCombined.AxWMP.status & " " & FrmCombined.AxWMP.Ctlcontrols.currentPosition)
            'Debug.Print(Me.AxWMP.Ctlcontrols.currentPosition) ' & " " & Me.AxWMP.status
            Application.DoEvents()
        Loop Until FrmCombined.AxWMP.status = "Stopped"
    End Sub

    Sub moveUp()

        Dim ii As Integer
        Dim arrayElement As Integer

        'Make sure our item is not the first one on the list.
        If FrmCombined.lbListPlaylist.SelectedIndex > 0 Then

            dontTriggerIndexChange = True
            ii = FrmCombined.lbListPlaylist.SelectedIndex - 1
            FrmCombined.lbListPlaylist.Items.Insert(ii, FrmCombined.lbListPlaylist.SelectedItem)
            FrmCombined.lbListPlaylist.Items.RemoveAt(FrmCombined.lbListPlaylist.SelectedIndex)
            FrmCombined.lbListPlaylist.SelectedIndex = ii

            dontTriggerIndexChange = False

            'SWAP ARRAY ELEMENTS TOO
            arrayElement = FrmCombined.lbListPlaylist.SelectedIndex + 1
            tempPlayListItem = playlistItems(arrayElement + 1)
            playlistItems(arrayElement + 1) = playlistItems(arrayElement)
            playlistItems(arrayElement) = tempPlayListItem

        End If

        Debug.Print("Move Up")
        For ii = 1 To mediaCount
            Debug.Print(playlistItems(ii).item)
        Next

    End Sub

    Function randomArr(ByVal l As Integer) As Integer()
        Dim templist(l) As Integer
        Dim rand As New Random
        Dim p As Integer
        Dim flag As Boolean = False

        p = rand.Next(1, l + 1)
        templist(0) = p



        For n As Integer = 1 To l - 1 Step 1
            flag = False
            p = rand.Next(1, l + 1)
            Do While flag = False
                For j As Integer = 0 To n - 1
                    If p = templist(j) Then
                        Exit For
                    ElseIf j = n - 1 Then
                        flag = True
                    End If
                Next
                If flag = False Then
                    p = rand.Next(1, l + 1)
                Else
                    templist(n) = p
                End If

            Loop

        Next

        Return templist


    End Function


End Module
