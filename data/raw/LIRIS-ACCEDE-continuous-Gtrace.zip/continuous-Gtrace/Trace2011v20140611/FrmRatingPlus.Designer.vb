﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmRatingPlus
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmRatingPlus))
        Me.btnDone = New System.Windows.Forms.Button()
        Me.lbox1 = New System.Windows.Forms.ListBox()
        Me.lbSelected = New System.Windows.Forms.ListBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.btnMoveRight = New System.Windows.Forms.Button()
        Me.btnMoveLeft = New System.Windows.Forms.Button()
        Me.btnMoveUp = New System.Windows.Forms.Button()
        Me.btnMoveDown = New System.Windows.Forms.Button()
        Me.lbox3 = New System.Windows.Forms.ListBox()
        Me.lbox2 = New System.Windows.Forms.ListBox()
        Me.lbox4 = New System.Windows.Forms.ListBox()
        Me.cbSaveSelected = New System.Windows.Forms.CheckBox()
        Me.btnClearAll = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btnDone
        '
        Me.btnDone.Font = New System.Drawing.Font("Cambria", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDone.Location = New System.Drawing.Point(775, 468)
        Me.btnDone.Name = "btnDone"
        Me.btnDone.Size = New System.Drawing.Size(93, 43)
        Me.btnDone.TabIndex = 1
        Me.btnDone.Text = "Done"
        Me.btnDone.UseVisualStyleBackColor = True
        '
        'lbox1
        '
        Me.lbox1.Font = New System.Drawing.Font("Cambria", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbox1.FormattingEnabled = True
        Me.lbox1.ItemHeight = 14
        Me.lbox1.Location = New System.Drawing.Point(32, 47)
        Me.lbox1.Name = "lbox1"
        Me.lbox1.Size = New System.Drawing.Size(194, 172)
        Me.lbox1.TabIndex = 2
        '
        'lbSelected
        '
        Me.lbSelected.Font = New System.Drawing.Font("Cambria", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbSelected.FormattingEnabled = True
        Me.lbSelected.ItemHeight = 14
        Me.lbSelected.Location = New System.Drawing.Point(562, 47)
        Me.lbSelected.Name = "lbSelected"
        Me.lbSelected.Size = New System.Drawing.Size(194, 368)
        Me.lbSelected.TabIndex = 3
        '
        'Label2
        '
        Me.Label2.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(562, 9)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(194, 35)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "Selected"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnMoveRight
        '
        Me.btnMoveRight.Font = New System.Drawing.Font("Cambria", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnMoveRight.Location = New System.Drawing.Point(440, 212)
        Me.btnMoveRight.Name = "btnMoveRight"
        Me.btnMoveRight.Size = New System.Drawing.Size(108, 71)
        Me.btnMoveRight.TabIndex = 6
        Me.btnMoveRight.Text = "Select"
        Me.btnMoveRight.UseVisualStyleBackColor = True
        '
        'btnMoveLeft
        '
        Me.btnMoveLeft.Font = New System.Drawing.Font("Cambria", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnMoveLeft.Location = New System.Drawing.Point(774, 276)
        Me.btnMoveLeft.Name = "btnMoveLeft"
        Me.btnMoveLeft.Size = New System.Drawing.Size(94, 45)
        Me.btnMoveLeft.TabIndex = 7
        Me.btnMoveLeft.Text = "Remove"
        Me.btnMoveLeft.UseVisualStyleBackColor = True
        '
        'btnMoveUp
        '
        Me.btnMoveUp.Font = New System.Drawing.Font("Cambria", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnMoveUp.Location = New System.Drawing.Point(774, 174)
        Me.btnMoveUp.Name = "btnMoveUp"
        Me.btnMoveUp.Size = New System.Drawing.Size(94, 45)
        Me.btnMoveUp.TabIndex = 9
        Me.btnMoveUp.Text = "Move Up"
        Me.btnMoveUp.UseVisualStyleBackColor = True
        '
        'btnMoveDown
        '
        Me.btnMoveDown.Font = New System.Drawing.Font("Cambria", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnMoveDown.Location = New System.Drawing.Point(774, 225)
        Me.btnMoveDown.Name = "btnMoveDown"
        Me.btnMoveDown.Size = New System.Drawing.Size(94, 45)
        Me.btnMoveDown.TabIndex = 10
        Me.btnMoveDown.Text = "Move Down"
        Me.btnMoveDown.UseVisualStyleBackColor = True
        '
        'lbox3
        '
        Me.lbox3.Font = New System.Drawing.Font("Cambria", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbox3.FormattingEnabled = True
        Me.lbox3.ItemHeight = 14
        Me.lbox3.Location = New System.Drawing.Point(232, 47)
        Me.lbox3.Name = "lbox3"
        Me.lbox3.Size = New System.Drawing.Size(194, 172)
        Me.lbox3.TabIndex = 11
        '
        'lbox2
        '
        Me.lbox2.Font = New System.Drawing.Font("Cambria", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbox2.FormattingEnabled = True
        Me.lbox2.ItemHeight = 14
        Me.lbox2.Location = New System.Drawing.Point(32, 242)
        Me.lbox2.Name = "lbox2"
        Me.lbox2.Size = New System.Drawing.Size(194, 172)
        Me.lbox2.TabIndex = 12
        '
        'lbox4
        '
        Me.lbox4.Font = New System.Drawing.Font("Cambria", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbox4.FormattingEnabled = True
        Me.lbox4.ItemHeight = 14
        Me.lbox4.Location = New System.Drawing.Point(232, 242)
        Me.lbox4.Name = "lbox4"
        Me.lbox4.Size = New System.Drawing.Size(194, 172)
        Me.lbox4.TabIndex = 13
        '
        'cbSaveSelected
        '
        Me.cbSaveSelected.Font = New System.Drawing.Font("Cambria", 10.0!)
        Me.cbSaveSelected.Location = New System.Drawing.Point(607, 440)
        Me.cbSaveSelected.Name = "cbSaveSelected"
        Me.cbSaveSelected.Size = New System.Drawing.Size(132, 32)
        Me.cbSaveSelected.TabIndex = 18
        Me.cbSaveSelected.Text = "Save Selected"
        Me.cbSaveSelected.UseVisualStyleBackColor = True
        '
        'btnClearAll
        '
        Me.btnClearAll.Font = New System.Drawing.Font("Cambria", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClearAll.Location = New System.Drawing.Point(198, 437)
        Me.btnClearAll.Name = "btnClearAll"
        Me.btnClearAll.Size = New System.Drawing.Size(81, 43)
        Me.btnClearAll.TabIndex = 19
        Me.btnClearAll.Text = "Clear All Selections"
        Me.btnClearAll.UseVisualStyleBackColor = True
        '
        'FrmRatingPlus
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(889, 537)
        Me.Controls.Add(Me.btnClearAll)
        Me.Controls.Add(Me.cbSaveSelected)
        Me.Controls.Add(Me.lbox4)
        Me.Controls.Add(Me.lbox2)
        Me.Controls.Add(Me.lbox3)
        Me.Controls.Add(Me.btnMoveDown)
        Me.Controls.Add(Me.btnMoveUp)
        Me.Controls.Add(Me.btnMoveLeft)
        Me.Controls.Add(Me.btnMoveRight)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.lbSelected)
        Me.Controls.Add(Me.lbox1)
        Me.Controls.Add(Me.btnDone)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "FrmRatingPlus"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "GTrace - Choose Ratings"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents btnDone As System.Windows.Forms.Button
    Friend WithEvents lbox1 As System.Windows.Forms.ListBox
    Friend WithEvents lbSelected As System.Windows.Forms.ListBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents btnMoveRight As System.Windows.Forms.Button
    Friend WithEvents btnMoveLeft As System.Windows.Forms.Button
    Friend WithEvents btnMoveUp As System.Windows.Forms.Button
    Friend WithEvents btnMoveDown As System.Windows.Forms.Button
    Friend WithEvents lbox3 As System.Windows.Forms.ListBox
    Friend WithEvents lbox2 As System.Windows.Forms.ListBox
    Friend WithEvents lbox4 As System.Windows.Forms.ListBox
    Friend WithEvents cbSaveSelected As System.Windows.Forms.CheckBox
    Friend WithEvents btnClearAll As System.Windows.Forms.Button
End Class
