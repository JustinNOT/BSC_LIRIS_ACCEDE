﻿Imports System.IO

Public Class FrmRatingPlus

    Private Sub FrmRatingPlus_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Dim filenames 'As Microsoft.VisualBasic.Collection

        Dim line As String
        Dim linenumber As Integer
        Dim rgbValues(3) As String
        Dim rangeValues(2) As String

        'Zero the count of selected ratings
        rpSelectedCount = 0

        'Allow multiple selections in each box
        Me.lbox1.SelectionMode = SelectionMode.MultiExtended
        Me.lbox2.SelectionMode = SelectionMode.MultiExtended
        Me.lbox3.SelectionMode = SelectionMode.MultiExtended
        Me.lbox4.SelectionMode = SelectionMode.MultiExtended
        Me.lbSelected.SelectionMode = SelectionMode.One 'only deselect one at a time

        Me.lbox1.Sorted = True
        Me.lbox2.Sorted = True
        Me.lbox3.Sorted = True
        Me.lbox4.Sorted = True
        Me.lbSelected.Sorted = False

        'Load contents of ratings subfolders

        'BOX1
        Me.lbox1.Items.Clear()
        filenames = My.Computer.FileSystem.GetFiles(plusFolder & "\1", FileIO.SearchOption.SearchTopLevelOnly, "*.rtg")   'Append subfolder
        ratingCount = 0
        For Each fileName As String In filenames
            sr = New StreamReader(fileName)
            ratingCount = ratingCount + 1
            linenumber = 0
            ratingPlusInfo(ratingCount, 1).neutralColour = False
            Do
                line = sr.ReadLine()
                Debug.WriteLine(line & " " & Microsoft.VisualBasic.Len(line))
                If Microsoft.VisualBasic.Len(line) > 0 Then
                    linenumber = linenumber + 1
                    Select Case linenumber
                        Case 1
                            ratingPlusInfo(ratingCount, 1).Description = line
                        Case 2
                            ratingPlusInfo(ratingCount, 1).JPGFile = plusFolder & "\1\" & line
                            If Not My.Computer.FileSystem.FileExists(ratingPlusInfo(ratingCount, 1).JPGFile) Then
                                MsgBox("JPEG file not found: " & ratingPlusInfo(ratingCount, 1).JPGFile)
                                End
                            End If
                            ratingPlusInfo(ratingCount, 1).JPG = Image.FromFile(ratingPlusInfo(ratingCount, 1).JPGFile)
                        Case 3
                            rangeValues = Split(line, ",")
                            ratingPlusInfo(ratingCount, 1).minRange = CInt(rangeValues(0))
                            ratingPlusInfo(ratingCount, 1).maxRange = CInt(rangeValues(1))
                            'MsgBox(fileName & vbTab & minRange & vbTab & maxRange & vbTab & coordRange)
                        Case 4
                            rgbValues = Split(line, ",")
                            ratingPlusInfo(ratingCount, 1).circleColourLeft = Color.FromArgb(255, CInt(rgbValues(0)), CInt(rgbValues(1)), CInt(rgbValues(2)))
                        Case 5
                            rgbValues = Split(line, ",")
                            ratingPlusInfo(ratingCount, 1).circleColourRight = Color.FromArgb(255, CInt(rgbValues(0)), CInt(rgbValues(1)), CInt(rgbValues(2)))
                        Case 6  'if this line exists, it is the neutral colour
                            rgbValues = Split(line, ",")
                            ratingPlusInfo(ratingCount, 1).circleColourNeutral = Color.FromArgb(255, CInt(rgbValues(0)), CInt(rgbValues(1)), CInt(rgbValues(2)))
                            ratingPlusInfo(ratingCount, 1).neutralColour = True
                    End Select
                End If
            Loop While sr.Peek <> -1
            sr.Close()
            'Add description to list
            lbox1.Items.Add(ratingPlusInfo(ratingCount, 1).Description)
        Next

        'BOX2
        Me.lbox2.Items.Clear()
        filenames = My.Computer.FileSystem.GetFiles(plusFolder & "\2", FileIO.SearchOption.SearchTopLevelOnly, "*.rtg")   'Append subfolder
        ratingCount = 0
        For Each fileName As String In filenames
            sr = New StreamReader(fileName)
            ratingCount = ratingCount + 1
            linenumber = 0
            ratingPlusInfo(ratingCount, 2).neutralColour = False
            Do
                line = sr.ReadLine()
                Debug.WriteLine(line & " " & Microsoft.VisualBasic.Len(line))
                If Microsoft.VisualBasic.Len(line) > 0 Then
                    linenumber = linenumber + 1
                    Select Case linenumber
                        Case 1
                            ratingPlusInfo(ratingCount, 2).Description = line
                        Case 2
                            ratingPlusInfo(ratingCount, 2).JPGFile = plusFolder & "\2\" & line
                            If Not My.Computer.FileSystem.FileExists(ratingPlusInfo(ratingCount, 2).JPGFile) Then
                                MsgBox("JPEG file not found: " & ratingPlusInfo(ratingCount, 2).JPGFile)
                                End
                            End If
                            ratingPlusInfo(ratingCount, 2).JPG = Image.FromFile(ratingPlusInfo(ratingCount, 2).JPGFile)
                        Case 3
                            rangeValues = Split(line, ",")
                            ratingPlusInfo(ratingCount, 2).minRange = CInt(rangeValues(0))
                            ratingPlusInfo(ratingCount, 2).maxRange = CInt(rangeValues(1))
                        Case 4
                            rgbValues = Split(line, ",")
                            ratingPlusInfo(ratingCount, 2).circleColourLeft = Color.FromArgb(255, CInt(rgbValues(0)), CInt(rgbValues(1)), CInt(rgbValues(2)))
                        Case 5
                            rgbValues = Split(line, ",")
                            ratingPlusInfo(ratingCount, 2).circleColourRight = Color.FromArgb(255, CInt(rgbValues(0)), CInt(rgbValues(1)), CInt(rgbValues(2)))
                        Case 6  'if this line exists, it is the neutral colour
                            rgbValues = Split(line, ",")
                            ratingPlusInfo(ratingCount, 2).circleColourNeutral = Color.FromArgb(255, CInt(rgbValues(0)), CInt(rgbValues(1)), CInt(rgbValues(2)))
                            ratingPlusInfo(ratingCount, 2).neutralColour = True
                    End Select
                End If
            Loop While sr.Peek <> -1
            sr.Close()
            'Add description to list
            lbox2.Items.Add(ratingPlusInfo(ratingCount, 2).Description)
        Next

        'BOX3
        Me.lbox3.Items.Clear()
        filenames = My.Computer.FileSystem.GetFiles(plusFolder & "\3", FileIO.SearchOption.SearchTopLevelOnly, "*.rtg")   'Append subfolder
        ratingCount = 0
        For Each fileName As String In filenames
            sr = New StreamReader(fileName)
            ratingCount = ratingCount + 1
            linenumber = 0
            ratingPlusInfo(ratingCount, 3).neutralColour = False
            Do
                line = sr.ReadLine()
                Debug.WriteLine(line & " " & Microsoft.VisualBasic.Len(line))
                If Microsoft.VisualBasic.Len(line) > 0 Then
                    linenumber = linenumber + 1
                    Select Case linenumber
                        Case 1
                            ratingPlusInfo(ratingCount, 3).Description = line
                        Case 2
                            ratingPlusInfo(ratingCount, 3).JPGFile = plusFolder & "\3\" & line
                            If Not My.Computer.FileSystem.FileExists(ratingPlusInfo(ratingCount, 3).JPGFile) Then
                                MsgBox("JPEG file not found: " & ratingPlusInfo(ratingCount, 3).JPGFile)
                                End
                            End If
                            ratingPlusInfo(ratingCount, 3).JPG = Image.FromFile(ratingPlusInfo(ratingCount, 3).JPGFile)
                        Case 3
                            rangeValues = Split(line, ",")
                            ratingPlusInfo(ratingCount, 3).minRange = CInt(rangeValues(0))
                            ratingPlusInfo(ratingCount, 3).maxRange = CInt(rangeValues(1))
                        Case 4
                            rgbValues = Split(line, ",")
                            ratingPlusInfo(ratingCount, 3).circleColourLeft = Color.FromArgb(255, CInt(rgbValues(0)), CInt(rgbValues(1)), CInt(rgbValues(2)))
                        Case 5
                            rgbValues = Split(line, ",")
                            ratingPlusInfo(ratingCount, 3).circleColourRight = Color.FromArgb(255, CInt(rgbValues(0)), CInt(rgbValues(1)), CInt(rgbValues(2)))
                        Case 6  'if this line exists, it is the neutral colour
                            rgbValues = Split(line, ",")
                            ratingPlusInfo(ratingCount, 3).circleColourNeutral = Color.FromArgb(255, CInt(rgbValues(0)), CInt(rgbValues(1)), CInt(rgbValues(2)))
                            ratingPlusInfo(ratingCount, 3).neutralColour = True
                    End Select
                End If
            Loop While sr.Peek <> -1
            sr.Close()
            'Add description to list
            lbox3.Items.Add(ratingPlusInfo(ratingCount, 3).Description)
        Next

        'BOX4
        Me.lbox4.Items.Clear()
        filenames = My.Computer.FileSystem.GetFiles(plusFolder & "\4", FileIO.SearchOption.SearchTopLevelOnly, "*.rtg")   'Append subfolder
        ratingCount = 0
        For Each fileName As String In filenames
            sr = New StreamReader(fileName)
            ratingCount = ratingCount + 1
            linenumber = 0
            ratingPlusInfo(ratingCount, 4).neutralColour = False
            Do
                line = sr.ReadLine()
                Debug.WriteLine(line & " " & Microsoft.VisualBasic.Len(line))
                If Microsoft.VisualBasic.Len(line) > 0 Then
                    linenumber = linenumber + 1
                    Select Case linenumber
                        Case 1
                            ratingPlusInfo(ratingCount, 4).Description = line
                        Case 2
                            ratingPlusInfo(ratingCount, 4).JPGFile = plusFolder & "\4\" & line
                            If Not My.Computer.FileSystem.FileExists(ratingPlusInfo(ratingCount, 4).JPGFile) Then
                                MsgBox("JPEG file not found: " & ratingPlusInfo(ratingCount, 4).JPGFile)
                                End
                            End If
                            ratingPlusInfo(ratingCount, 4).JPG = Image.FromFile(ratingPlusInfo(ratingCount, 4).JPGFile)
                        Case 3
                            rangeValues = Split(line, ",")
                            ratingPlusInfo(ratingCount, 4).minRange = CInt(rangeValues(0))
                            ratingPlusInfo(ratingCount, 4).maxRange = CInt(rangeValues(1))
                        Case 4
                            rgbValues = Split(line, ",")
                            ratingPlusInfo(ratingCount, 4).circleColourLeft = Color.FromArgb(255, CInt(rgbValues(0)), CInt(rgbValues(1)), CInt(rgbValues(2)))
                        Case 5
                            rgbValues = Split(line, ",")
                            ratingPlusInfo(ratingCount, 4).circleColourRight = Color.FromArgb(255, CInt(rgbValues(0)), CInt(rgbValues(1)), CInt(rgbValues(2)))
                        Case 6  'if this line exists, it is the neutral colour
                            rgbValues = Split(line, ",")
                            ratingPlusInfo(ratingCount, 4).circleColourNeutral = Color.FromArgb(255, CInt(rgbValues(0)), CInt(rgbValues(1)), CInt(rgbValues(2)))
                            ratingPlusInfo(ratingCount, 4).neutralColour = True
                    End Select
                End If
            Loop While sr.Peek <> -1
            sr.Close()
            'Add description to list
            lbox4.Items.Add(ratingPlusInfo(ratingCount, 4).Description)
        Next


    End Sub

    Private Sub btnDone_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDone.Click

        Dim strSelectionSave As String
        Dim i As Integer

        ' If rpSelectedCount > 0 Then
        If Me.lbSelected.Items.Count > 0 Then

            'Must write selected list out to a file
            If Me.cbSaveSelected.Checked = True Then
                If FrmStartup.txtID.Text = "" Then
                    strSelectionSave = InputBox("Enter name to save selection under: ")
                Else
                    strSelectionSave = FrmStartup.txtID.Text
                End If
                strRatingPlusDataFile = dataFolder & "\" & strSelectionSave & ".SLT"
                sw = New StreamWriter(strRatingPlusDataFile)
                'sw.WriteLine(mediaFolder & "\" & FrmCombined.lbListPlaylist.SelectedItem.ToString)
                sw.WriteLine(playlistItems(FrmCombined.lbListPlaylist.SelectedIndex + 1).item)
                For i = 1 To rpSelectedCount
                    ratingPlusSelected(i).rated = False
                    sw.Write(ratingPlusSelected(i).Description)
                    sw.Write(vbTab & ratingPlusSelected(i).JPGFile)
                    sw.Write(vbTab & ratingPlusSelected(i).minRange & "," & ratingPlusSelected(i).maxRange)
                    sw.Write(vbTab & ratingPlusSelected(i).circleColourLeft.R & "," & ratingPlusSelected(i).circleColourLeft.G & "," & ratingPlusSelected(i).circleColourLeft.B)
                    sw.Write(vbTab & ratingPlusSelected(i).circleColourRight.R & "," & ratingPlusSelected(i).circleColourRight.G & "," & ratingPlusSelected(i).circleColourRight.B)
                    If ratingPlusSelected(i).neutralColour = True Then
                        sw.Write(vbTab & ratingPlusSelected(i).circleColourNeutral.R & "," & ratingPlusSelected(i).circleColourNeutral.G & "," & ratingPlusSelected(i).circleColourNeutral.B)
                    End If
                    'sw.WriteLine()
                    sw.WriteLine(vbTab & ratingPlusSelected(i).rated)
                Next
                sw.Close()
            End If

            'Now clear ratings box of current listings and add these selected
            FrmCombined.lbRatings.Items.Clear()
            For i = 1 To rpSelectedCount
                FrmCombined.lbRatings.Items.Add(ratingPlusSelected(i).Description)
            Next

            'Select 1st rating in list in FrmCombined
            FrmCombined.lbRatings.SelectedIndex = 0
            ratingImage = ratingPlusSelected(FrmCombined.lbRatings.SelectedIndex + 1).JPG
            ratingDescription = ratingPlusSelected(FrmCombined.lbRatings.SelectedIndex + 1).Description
            ratingJPG = ratingPlusSelected(FrmCombined.lbRatings.SelectedIndex + 1).JPGFile
            minRange = ratingPlusSelected(FrmCombined.lbRatings.SelectedIndex + 1).minRange
            maxRange = ratingPlusSelected(FrmCombined.lbRatings.SelectedIndex + 1).maxRange
            coordRange = maxRange - minRange
            circleColour(1) = ratingPlusSelected(FrmCombined.lbRatings.SelectedIndex + 1).circleColourLeft
            circleColour(2) = ratingPlusSelected(FrmCombined.lbRatings.SelectedIndex + 1).circleColourRight
            neutralColour = ratingPlusSelected(FrmCombined.lbRatings.SelectedIndex + 1).neutralColour
            If neutralColour = True Then
                circleColour(3) = ratingPlusSelected(FrmCombined.lbRatings.SelectedIndex + 1).circleColourNeutral
            End If
            FrmCombined.MousePanel.BackgroundImage = ratingImage
            FrmCombined.MousePanel.BackgroundImageLayout = ImageLayout.None
            ratingSelected = True

            're-select same video
            'FrmCombined.AxWMP.URL = mediaFolder & "\" & FrmCombined.lbListPlaylist.SelectedItem.ToString
            FrmCombined.AxWMP.URL = playlistItems(FrmCombined.lbListPlaylist.SelectedIndex + 1).item
            Do
                Application.DoEvents()
            Loop Until FrmCombined.AxWMP.playState = WMPLib.WMPPlayState.wmppsPlaying '"Playing"
            WMPcontrols1.pause()
            WMPcontrols1.currentPosition = 0 'rewind to start
            clipselected = True

            'Re-set plusOption
            plusOption = plusOptionWithRatings

        End If

        Me.Close()
        FrmCombined.Show()

    End Sub


    Private Sub btnMoveRight_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnMoveRight.Click

        Dim i As Integer

        If lbox1.SelectedIndices.Count > 0 Then
            For i = 0 To lbox1.SelectedIndices.Count - 1
                rpSelectedCount = rpSelectedCount + 1
                ratingPlusSelected(rpSelectedCount) = ratingPlusInfo(lbox1.SelectedIndices(i) + 1, 1)
                Me.lbSelected.Items.Add(ratingPlusInfo(lbox1.SelectedIndices(i) + 1, 1).Description)
            Next
        End If

        If lbox2.SelectedIndices.Count > 0 Then
            For i = 0 To lbox2.SelectedIndices.Count - 1
                rpSelectedCount = rpSelectedCount + 1
                ratingPlusSelected(rpSelectedCount) = ratingPlusInfo(lbox2.SelectedIndices(i) + 1, 2)
                Me.lbSelected.Items.Add(ratingPlusInfo(lbox2.SelectedIndices(i) + 1, 2).Description)
            Next
        End If

        If lbox3.SelectedIndices.Count > 0 Then
            For i = 0 To lbox3.SelectedIndices.Count - 1
                rpSelectedCount = rpSelectedCount + 1
                ratingPlusSelected(rpSelectedCount) = ratingPlusInfo(lbox3.SelectedIndices(i) + 1, 3)
                Me.lbSelected.Items.Add(ratingPlusInfo(lbox3.SelectedIndices(i) + 1, 3).Description)
            Next
        End If

        If lbox4.SelectedIndices.Count > 0 Then
            For i = 0 To lbox4.SelectedIndices.Count - 1
                rpSelectedCount = rpSelectedCount + 1
                ratingPlusSelected(rpSelectedCount) = ratingPlusInfo(lbox4.SelectedIndices(i) + 1, 4)
                Me.lbSelected.Items.Add(ratingPlusInfo(lbox4.SelectedIndices(i) + 1, 4).Description)
            Next
        End If

        ' Debug.Print("MoveRight")
        ' Debug.Print(rpSelectedCount)
        ' For i = 1 To rpSelectedCount
        'Debug.Print(ratingPlusSelected(i).Description)
        'Next

    End Sub

    Private Sub btnMoveLeft_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnMoveLeft.Click

        Dim ii As Integer
        Dim arrayElement As Integer

        'RESTRICTION: Can only move 1 left at a time
        If Me.lbSelected.Items.Count > 0 Then
            If lbSelected.SelectedIndex > -1 Then
                arrayElement = lbSelected.SelectedIndex + 1
                'Debug.Print(arrayElement)
                For ii = arrayElement To rpSelectedCount - 1
                    ratingPlusSelected(ii) = ratingPlusSelected(ii + 1)
                Next
                rpSelectedCount = rpSelectedCount - 1
                ' Debug.Print(rpSelectedCount)
                Me.lbSelected.Items.RemoveAt(lbSelected.SelectedIndex)
            End If
        End If

        'If rpSelectedCount > 0 And lbSelected.SelectedIndices.Count > 0 Then
        ' For Each i In lbSelected.SelectedIndices
        ' arrayElement = i + 1
        ' Debug.Print(lbSelected.SelectedIndices.Count & " " & arrayElement)
        ' For ii = arrayElement To rpSelectedCount - 1
        ' ratingPlusSelected(ii) = ratingPlusSelected(ii + 1)
        ' Next
        ' rpSelectedCount = rpSelectedCount - 1
        ' Me.lbSelected.Items.RemoveAt(i)
        ' Next
        'End If

        '   'Now remove from list
        '   If rpSelectedCount > 0 And lbSelected.SelectedIndices.Count > 0 Then
        ' For i = 0 To lbSelected.SelectedIndices.Count - 1
        ' Me.lbSelected.Items.RemoveAt(i)
        ' Next
        ' End If

        'Debug.Print("MoveLeft")
        'Debug.Print("arrayElement " & arrayElement)
        'Debug.Print(rpSelectedCount)
        'For i = 1 To rpSelectedCount
        'Debug.Print(ratingPlusSelected(i).Description)
        'Next

    End Sub

    Private Sub btnMoveUp_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnMoveUp.Click

        Dim ii As Integer
        Dim arrayElement As Integer

        If Me.lbSelected.Items.Count > 0 Then
            'Make sure our item is not the first one on the list.
            If Me.lbSelected.SelectedIndex > 0 Then

                arrayElement = Me.lbSelected.SelectedIndex + 1

                ii = Me.lbSelected.SelectedIndex - 1
                Me.lbSelected.Items.Insert(ii, Me.lbSelected.SelectedItem)
                Me.lbSelected.Items.RemoveAt(Me.lbSelected.SelectedIndex)
                Me.lbSelected.SelectedIndex = ii

                'SWAP ARRAY ELEMENTS TOO
                tempRatingInfo = ratingPlusSelected(arrayElement - 1)
                ratingPlusSelected(arrayElement - 1) = ratingPlusSelected(arrayElement)
                ratingPlusSelected(arrayElement) = tempRatingInfo

            End If

        End If

        'Debug.Print("MoveUp")
        'Debug.Print("arrayElement " & arrayElement)
        'Debug.Print(rpSelectedCount)
        'For i = 1 To rpSelectedCount
        ' Debug.Print(ratingPlusSelected(i).Description)
        ' Next

    End Sub

    Private Sub btnMoveDown_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnMoveDown.Click

        Dim ii As Integer
        Dim arrayElement As Integer

        If Me.lbSelected.Items.Count > 0 Then
            'Make sure our item is not the last one on the list.
            If Me.lbSelected.SelectedIndex < Me.lbSelected.Items.Count - 1 Then

                arrayElement = Me.lbSelected.SelectedIndex + 1

                'Insert places items above the index you supply, since we want
                'to move it down the list we have to do + 2
                ii = Me.lbSelected.SelectedIndex + 2
                Me.lbSelected.Items.Insert(ii, Me.lbSelected.SelectedItem)
                Me.lbSelected.Items.RemoveAt(Me.lbSelected.SelectedIndex)
                Me.lbSelected.SelectedIndex = ii - 1

                'SWAP ARRAY ELEMENTS TOO
                tempRatingInfo = ratingPlusSelected(arrayElement + 1)
                ratingPlusSelected(arrayElement + 1) = ratingPlusSelected(arrayElement)
                ratingPlusSelected(arrayElement) = tempRatingInfo
            End If
        End If

        'Debug.Print("MoveDown")
        'Debug.Print("arrayElement " & arrayElement)
        'Debug.Print(rpSelectedCount)
        'For i = 1 To rpSelectedCount
        ' Debug.Print(ratingPlusSelected(i).Description)
        ' Next

    End Sub

    Private Sub btnClearAll_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClearAll.Click

        lbox1.ClearSelected()
        lbox2.ClearSelected()
        lbox3.ClearSelected()
        lbox4.ClearSelected()

    End Sub

End Class