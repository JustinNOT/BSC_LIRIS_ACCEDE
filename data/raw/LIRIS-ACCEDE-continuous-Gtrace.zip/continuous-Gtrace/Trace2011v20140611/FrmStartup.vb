﻿Imports System.IO

Public Class FrmStartup

    Private Sub btnStart_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnStart.Click

        Me.Hide()

        'Initialise
        sbcount = 0
        clipselected = False
        ratingSelected = False
        'clipCount = 0

        FrmCombined.Show()
    End Sub

    Private Sub btnQuit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnQuit.Click

        End

    End Sub

    Private Sub FrmStartup_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Dim tempFolder As String

        'Initialise plusOption
        plusOption = plusOptionOff
        strRatingPlusDataFile = ""
        Me.cbPlusOption.Checked = False
        Me.btnLoadPreSelected.Enabled = False

        'Make sure txtID empty
        Me.txtID.Text = ""

        ' Set the default directory of the folder browser to the current directory.
        FolderBrowserDialog1.SelectedPath = My.Computer.FileSystem.CurrentDirectory
        'Set to Documents folder
        'FolderBrowserDialog1.SelectedPath = Environment.SpecialFolder.MyDocuments
        'FolderBrowserDialog1.SelectedPath = My.Computer.FileSystem.CurrentDirectory & "..\\.."

        tempFolder = Directory.GetCurrentDirectory
        homeFolder = Directory.GetParent(tempFolder).FullName
        Directory.SetCurrentDirectory(homeFolder)
        ' tempFolder = Directory.GetCurrentDirectory
        homeFolder = Directory.GetParent(homeFolder).FullName
        Directory.SetCurrentDirectory(homeFolder)
        mediaFolder = homeFolder & "\Media"
        ratingsFolder = homeFolder & "\Ratings"
        dataFolder = homeFolder & "\Data"
        plusFolder = homeFolder & "\RatingsPlus"
        'Debug.Print(homeFolder)
        'Debug.Print(mediaFolder)
        'Debug.Print(ratingsFolder)

    End Sub

    '  Private Sub btnSetRatingsFolder_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    '  Dim filenames
    '  Dim filenameOnly As String
    '
    '        If FolderBrowserDialog1.ShowDialog() = DialogResult.OK Then
    '
    '    'cmboSelectRating.Items.Clear()
    '            lbListRating.Items.Clear()
    '
    '            filenames = My.Computer.FileSystem.GetFiles(FolderBrowserDialog1.SelectedPath, FileIO.SearchOption.SearchTopLevelOnly, "*.txt")
    '
    '            For Each fileName As String In filenames
    '                filenameOnly = IO.Path.GetFileName(fileName)
    '    'cmboSelectRating.Items.Add(filenameOnly)
    '                lbListRating.Items.Add(filenameOnly)
    '            Next
    '
    '        End If
    '
    '   End Sub

    Private Sub btnSetPlayListFolder_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

        'NOT USED - This sub relates to when users could select playlists on Startup form

        Dim myStream As Stream = Nothing
        Dim openFileDialog1 As New OpenFileDialog()


        'Clear list box
        'Need to comment out below as control not there any more
        'lbListPlaylist.Items.Clear()

        mediaCount = 0

        openFileDialog1.InitialDirectory = mediaFolder
        openFileDialog1.Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*"
        openFileDialog1.FilterIndex = 1
        'openFileDialog1.Filter = "WMV files (*.wmv)|*.wmv|MPG files (*.mpg)|*.mpg|AVI files (*.avi)|*.avi|All files (*.*)|*.*"
        'openFileDialog1.FilterIndex = 4

        If openFileDialog1.ShowDialog() = System.Windows.Forms.DialogResult.OK Then

            Try
                ' Create an instance of StreamReader to read from a file.
                Dim sr As StreamReader = New StreamReader(openFileDialog1.OpenFile())
                Dim line As String
                ' Read and display the lines from the file until the end of the file is reached.
                Do
                    line = sr.ReadLine()
                    If line <> "" Then
                        mediaCount = mediaCount + 1
                        playlistItems(mediaCount).item = line
                        playlistItems(mediaCount).folder = Path.GetDirectoryName(openFileDialog1.FileName)  'path
                        playlistItems(mediaCount).playCount = 0
                        playlistItems(mediaCount).dataCollected = False
                        'Need to comment out below as control not there any more
                        'Me.lbListPlaylist.Items.Add(CStr(mediaCount) & vbTab & playlistItems(mediaCount).item)
                    End If
                Loop Until line Is Nothing
                sr.Close()
                'mediaFolder = Path.GetDirectoryName(openFileDialog1.FileName)
                'MsgBox(mediaFolder)
            Catch Ex As Exception
                ' Let the user know what went wrong.
                Console.WriteLine("The file could not be read: ")
                Console.WriteLine(Ex.Message)
            End Try

        End If

    End Sub


    Private Sub chkSaveData_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkSaveData.CheckedChanged

        If Me.chkSaveData.Checked = True Then
            Me.txtID.Enabled = True
            Me.lblID.Enabled = True
            saveData = True
        Else
            Me.txtID.Enabled = False
            Me.lblID.Enabled = False
            saveData = False
        End If

    End Sub

    Private Sub cbPlusOption_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cbPlusOption.CheckedChanged

        If Me.cbPlusOption.Checked = True Then
            If plusOption = plusOptionOff Then
                plusOption = plusOptionNoRatings
            End If
            Me.btnLoadPreSelected.Enabled = True
        Else
            Me.btnLoadPreSelected.Enabled = False
            'If plusOption = plusOptionNoRatings Then
            plusOption = plusOptionOff  'Turn off regardless of existing state
            'End If
        End If
    End Sub

    Private Sub btnLoadPreSelected_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLoadPreSelected.Click

        Dim myStream As Stream = Nothing
        Dim openFileDialog1 As New OpenFileDialog()

        'Local
        Dim line As String
        Dim mediaFile As String
        Dim rgbValues(3) As String
        Dim rangeValues(2) As String

        Dim nFields As Integer

        Dim delimStr As String = Chr(9) 'tab
        Dim delimiter As Char() = delimStr.ToCharArray()

        rpSelectedCount = 0

        openFileDialog1.InitialDirectory = dataFolder
        openFileDialog1.Filter = "SLT files (*.slt)|*.slt|All files (*.*)|*.*"
        openFileDialog1.FilterIndex = 1

        If openFileDialog1.ShowDialog() = System.Windows.Forms.DialogResult.OK Then
            'selectionFile = openFileDialog1.FileName
            strRatingPlusDataFile = openFileDialog1.FileName
            sr = New StreamReader(strRatingPlusDataFile)
            'Read media file name
            mediaFile = sr.ReadLine()
            ratingPlusSelected(rpSelectedCount).neutralColour = False
            Do
                line = sr.ReadLine()
                'Debug.WriteLine(line & " " & Microsoft.VisualBasic.Len(line))
                rpSelectedCount = rpSelectedCount + 1

                Dim parsed() As String = Split(line, delimiter)
                nFields = parsed.Length
                'Debug.WriteLine(nFields)

                ratingPlusSelected(rpSelectedCount).Description = parsed(0)
                'Debug.Print(ratingPlusSelected(rpSelectedCount).Description)

                ratingPlusSelected(rpSelectedCount).JPGFile = parsed(1)
                If Not My.Computer.FileSystem.FileExists(ratingPlusSelected(rpSelectedCount).JPGFile) Then
                    MsgBox("JPEG file not found: " & ratingPlusSelected(rpSelectedCount).JPGFile)
                    End
                End If
                ratingPlusSelected(rpSelectedCount).JPG = Image.FromFile(ratingPlusSelected(rpSelectedCount).JPGFile)
                'Debug.Print(ratingPlusSelected(rpSelectedCount).JPGFile)

                rangeValues = Split(parsed(2), ",")
                ratingPlusSelected(rpSelectedCount).minRange = CInt(rangeValues(0))
                ratingPlusSelected(rpSelectedCount).maxRange = CInt(rangeValues(1))
                'coordRange = maxRange - minRange

                rgbValues = Split(parsed(3), ",")
                'Debug.Print(rgbValues(0) & rgbValues(1) & rgbValues(2))
                ratingPlusSelected(rpSelectedCount).circleColourLeft = Color.FromArgb(255, CInt(rgbValues(0)), CInt(rgbValues(1)), CInt(rgbValues(2)))

                rgbValues = Split(parsed(4), ",")
                'Debug.Print(rgbValues(0) & rgbValues(1) & rgbValues(2))
                ratingPlusSelected(rpSelectedCount).circleColourRight = Color.FromArgb(255, CInt(rgbValues(0)), CInt(rgbValues(1)), CInt(rgbValues(2)))

                If nFields = 7 Then
                    rgbValues = Split(parsed(5), ",")
                    'Debug.Print(rgbValues(0) & rgbValues(1) & rgbValues(2))
                    ratingPlusSelected(rpSelectedCount).circleColourNeutral = Color.FromArgb(255, CInt(rgbValues(0)), CInt(rgbValues(1)), CInt(rgbValues(2)))
                    ratingPlusSelected(rpSelectedCount).neutralColour = True
                End If

                If nFields = 6 Then
                    ratingPlusSelected(rpSelectedCount).rated = parsed(5)
                ElseIf nFields = 7 Then
                    ratingPlusSelected(rpSelectedCount).rated = parsed(6)
                End If
                Debug.Print(ratingPlusSelected(rpSelectedCount).rated)

                'Add description to list
                If ratingPlusSelected(rpSelectedCount).rated = True Then
                    FrmCombined.lbRatings.Items.Add("RATED " & ratingPlusSelected(rpSelectedCount).Description)
                ElseIf ratingPlusSelected(rpSelectedCount).rated = False Then
                    FrmCombined.lbRatings.Items.Add(ratingPlusSelected(rpSelectedCount).Description)
                End If

            Loop While sr.Peek <> -1
            sr.Close()

            'Set plusOption then check and disable the checkbox - can't go back unless exit program
            plusOption = plusOptionWithRatings
            Me.cbPlusOption.Checked = True
            Me.cbPlusOption.Enabled = False

            'Display warning about media file
            MsgBox("Note - the ratings in this SLT file relate to the media file:" & Chr(13) & mediaFile)

        End If

    End Sub

End Class