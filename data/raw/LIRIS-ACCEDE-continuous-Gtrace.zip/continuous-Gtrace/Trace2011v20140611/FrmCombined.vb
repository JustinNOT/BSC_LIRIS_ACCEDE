﻿Imports System.IO
Public Class FrmCombined

    Private Sub FrmCombined_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Leave

    End Sub

    Private Sub FrmCombined_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim filenames 'As Microsoft.VisualBasic.Collection
        Dim filenameOnly As String
        Dim ratingsLoadFolder As String

        Dim sr As StreamReader
        Dim line As String
        Dim linenumber As Integer
        Dim rgbValues(3) As String
        Dim rangeValues(2) As String

        Me.lblUserName.Text = "Identifier: " & FrmStartup.txtID.Text

        displayState = 1 '1=FULL, 0=MINIMAL
        Me.AxWMP.uiMode = "full"  '"none" "mini" or "full"
        Me.AxWMP.settings.volume = 100  'volume to the max so that we can change the volume using the windows volume setting bar"
        dontTriggerIndexChange = False ' this is for the playlist

        ' 'Display items in current playlist
        ' Me.lbListPlaylist.Items.Clear()
        ' For i = 1 To mediaCount
        ' Me.lbListPlaylist.Items.Add(playlistItems(i).item)
        ' ' Me.lbListPlaylist.Items.Add(playlistItems(i).item & vbTab & playlistItems(i).playCount & vbTab & playlistItems(i).dataCollected)
        ' Next

        'Load contents of Media folder - any AVI, MPG, WMA, MP4, MOV. 
        'Doesn't mean this is all that can be played, just all that will be displayed automatically
        Me.lbListPlaylist.Items.Clear()
        mediaCount = 0
        Me.lbListPlaylist.Sorted = False 'this will not sort them alpabetically - load initially then set to false to allow re-ordering
        filenames = My.Computer.FileSystem.GetFiles(mediaFolder, FileIO.SearchOption.SearchTopLevelOnly, "*.mpg")
        For Each fileName As String In filenames
            filenameOnly = IO.Path.GetFileName(fileName)
            Me.lbListPlaylist.Items.Add(filenameOnly)
            mediaCount = mediaCount + 1
            playlistItems(mediaCount).item = fileName
            playlistItems(mediaCount).folder = mediaFolder 'path
            playlistItems(mediaCount).playCount = 0
            playlistItems(mediaCount).dataCollected = False
        Next
        filenames = My.Computer.FileSystem.GetFiles(mediaFolder, FileIO.SearchOption.SearchTopLevelOnly, "*.wmv")
        For Each fileName As String In filenames
            filenameOnly = IO.Path.GetFileName(fileName)
            Me.lbListPlaylist.Items.Add(filenameOnly)
            mediaCount = mediaCount + 1
            playlistItems(mediaCount).item = fileName
            playlistItems(mediaCount).folder = mediaFolder 'path
            playlistItems(mediaCount).playCount = 0
            playlistItems(mediaCount).dataCollected = False
        Next
        filenames = My.Computer.FileSystem.GetFiles(mediaFolder, FileIO.SearchOption.SearchTopLevelOnly, "*.avi")
        For Each fileName As String In filenames
            filenameOnly = IO.Path.GetFileName(fileName)
            Me.lbListPlaylist.Items.Add(filenameOnly)
            mediaCount = mediaCount + 1
            playlistItems(mediaCount).item = fileName
            playlistItems(mediaCount).folder = mediaFolder 'path
            playlistItems(mediaCount).playCount = 0
            playlistItems(mediaCount).dataCollected = False
        Next
        filenames = My.Computer.FileSystem.GetFiles(mediaFolder, FileIO.SearchOption.SearchTopLevelOnly, "*.mp4")
        For Each fileName As String In filenames
            filenameOnly = IO.Path.GetFileName(fileName)
            Me.lbListPlaylist.Items.Add(filenameOnly)
            mediaCount = mediaCount + 1
            playlistItems(mediaCount).item = fileName
            playlistItems(mediaCount).folder = mediaFolder 'path
            playlistItems(mediaCount).playCount = 0
            playlistItems(mediaCount).dataCollected = False
        Next
        filenames = My.Computer.FileSystem.GetFiles(mediaFolder, FileIO.SearchOption.SearchTopLevelOnly, "*.mov")
        For Each fileName As String In filenames
            filenameOnly = IO.Path.GetFileName(fileName)
            Me.lbListPlaylist.Items.Add(filenameOnly)
            mediaCount = mediaCount + 1
            playlistItems(mediaCount).item = fileName
            playlistItems(mediaCount).folder = mediaFolder 'path
            playlistItems(mediaCount).playCount = 0
            playlistItems(mediaCount).dataCollected = False
        Next
        Me.lbListPlaylist.Sorted = False

        'Don't load playlist by default any more
        'For i = 1 To mediaCount
        ' Me.lbListPlaylist.Items.Add(playlistItems(i).item)
        ' Next


        'Load ratings
        'if plusOptionOff then use ratingsFolder
        'if plusOptionNoRatings then use plusFolder
        'if plusOptionWithRatings then don't need to load
        If plusOption <> plusOptionWithRatings Then
            Me.lbRatings.Items.Clear()
            'Me.lbRatings.Sorted = True 'this will sort them alpabetically - load initially then set to false to allow re-ordering
            Me.lbRatings.Sorted = False
            If plusOption = plusOptionOff Then
                ratingsLoadFolder = ratingsFolder
            Else                 ' plusOption = plusOptionNoRatings 
                ratingsLoadFolder = plusFolder
            End If
            filenames = My.Computer.FileSystem.GetFiles(ratingsLoadFolder, FileIO.SearchOption.SearchTopLevelOnly, "*.rtg")

            ratingCount = 0
            For Each fileName As String In filenames
                'sr = New StreamReader(fileName)

                'line = sr.ReadLine() 'Just read 1st line to get description
                'lbRatings.Items.Add(line)

                ' filenameOnly = IO.Path.GetFileName(fileName)
                ' basenameOnly = Microsoft.VisualBasic.Left(filenameOnly, Microsoft.VisualBasic.Len(filenameOnly) - 4) 'Only display base name
                ' lbRatings.Items.Add(basenameOnly)

                sr = New StreamReader(fileName)
                ratingCount = ratingCount + 1
                linenumber = 0
                ratingInfo(ratingCount).neutralColour = False
                Do  'this loop will loop a rtg file to write the information in this file into a ratingInfo varialble
                    line = sr.ReadLine()
                    Debug.WriteLine(line & " " & Microsoft.VisualBasic.Len(line))
                    If Microsoft.VisualBasic.Len(line) > 0 Then
                        linenumber = linenumber + 1
                        Select Case linenumber
                            Case 1
                                'ratingDescription = line
                                ratingInfo(ratingCount).Description = line
                            Case 2
                                ' ratingJPG = ratingsFolder & "\" & line
                                ratingInfo(ratingCount).JPGFile = ratingsLoadFolder & "\" & line
                                If Not My.Computer.FileSystem.FileExists(ratingInfo(ratingCount).JPGFile) Then
                                    MsgBox("JPEG file not found: " & ratingInfo(ratingCount).JPGFile)
                                    End
                                End If
                                ratingInfo(ratingCount).JPG = Image.FromFile(ratingInfo(ratingCount).JPGFile)
                            Case 3
                                rangeValues = Split(line, ",")
                                minRange = CInt(rangeValues(0))
                                maxRange = CInt(rangeValues(1))
                                coordRange = maxRange - minRange
                                ratingInfo(ratingCount).minRange = minRange
                                ratingInfo(ratingCount).maxRange = maxRange
                                'MsgBox(fileName & vbTab & minRange & vbTab & maxRange & vbTab & coordRange)
                            Case 4
                                rgbValues = Split(line, ",")
                                'Debug.Print(rgbValues(0) & rgbValues(1) & rgbValues(2))
                                'circleColour(1) = Color.FromArgb(255, CInt(rgbValues(0)), CInt(rgbValues(1)), CInt(rgbValues(2)))
                                ratingInfo(ratingCount).circleColourLeft = Color.FromArgb(255, CInt(rgbValues(0)), CInt(rgbValues(1)), CInt(rgbValues(2)))
                            Case 5
                                rgbValues = Split(line, ",")
                                'Debug.Print(rgbValues(0) & rgbValues(1) & rgbValues(2))
                                'circleColour(2) = Color.FromArgb(255, CInt(rgbValues(0)), CInt(rgbValues(1)), CInt(rgbValues(2)))
                                ratingInfo(ratingCount).circleColourRight = Color.FromArgb(255, CInt(rgbValues(0)), CInt(rgbValues(1)), CInt(rgbValues(2)))
                            Case 6  'if this line exists, it is the neutral colour
                                rgbValues = Split(line, ",")
                                'Debug.Print(rgbValues(0) & rgbValues(1) & rgbValues(2))
                                ' circleColour(3) = Color.FromArgb(255, CInt(rgbValues(0)), CInt(rgbValues(1)), CInt(rgbValues(2)))
                                ratingInfo(ratingCount).circleColourNeutral = Color.FromArgb(255, CInt(rgbValues(0)), CInt(rgbValues(1)), CInt(rgbValues(2)))
                                ratingInfo(ratingCount).neutralColour = True
                        End Select
                    End If
                Loop While sr.Peek <> -1
                sr.Close()
                'Add description to list
                lbRatings.Items.Add(ratingInfo(ratingCount).Description)

            Next
            Me.lbRatings.Sorted = False
        End If

        'Some initial setup
        intMBwidth = Me.MousePanel.Width
        intMBheight = Me.MousePanel.Height
        intMBleft = Me.MousePanel.Left
        intMBtop = Me.MousePanel.Top

        '<---------------the position of the cursor on the rating scale----->
        'rectangleWidth = 66 * CSng(intMBwidth) / 100
        rectangleWidth = 660
        'rectangleHeight = 25 * CSng(intMBheight) / 100
        rectangleHeight = 82
        'rectangleLeft = 1 * CSng(intMBwidth) / 100
        rectangleLeft = 100
        'rectangleTop = 37.5 * CSng(intMBheight) / 100
        rectangleTop = 36
        rectangleRight = rectangleLeft + rectangleWidth
        rectangleBottom = rectangleTop + rectangleHeight

        'Create graphics
        gPanel = Me.MousePanel.CreateGraphics()

        'Use default doublebuffering context
        ' Creates a BufferedGraphics instance associated with MousePanel, and with 
        ' dimensions the same size as the drawing surface of MousePanel.
        BufferedContext = BufferedGraphicsManager.Current
        doubleBuffer = BufferedContext.Allocate(gPanel, Me.MousePanel.DisplayRectangle)

        'Do an initial clear of the buffer
        doubleBuffer.Graphics.Clear(Color.White)
        doubleBuffer.Render()


    End Sub

    Private Sub btnQuit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnQuit.Click

        Dim msgBoxResp As Integer
        Dim strSelectionSave As String

        gPanel.Dispose()
        doubleBuffer.Graphics.Dispose()

        'For plusOption, update rated list
        If plusOption = plusOptionWithRatings Then
            msgBoxResp = MsgBox("Update Plus Option rated data?", MsgBoxStyle.YesNo, "Plus Option")
            If msgBoxResp = Microsoft.VisualBasic.MsgBoxResult.Yes Then
                'Must write selected list out to a file
                If strRatingPlusDataFile = "" Then
                    If FrmStartup.txtID.Text = "" Then
                        strSelectionSave = InputBox("Enter name to save selection under: ")
                    Else
                        strSelectionSave = FrmStartup.txtID.Text
                    End If
                    strRatingPlusDataFile = dataFolder & "\" & strSelectionSave & ".SLT"
                End If
                'Can only have got here with strRatingPlusDataFile already set
                ' sw = New StreamWriter(dataFolder & "\" & strSelectionSave & ".SLT")
                sw = New StreamWriter(strRatingPlusDataFile)
                'sw.WriteLine(mediaFolder & "\" & Me.lbListPlaylist.SelectedItem.ToString)
                sw.WriteLine(playlistItems(Me.lbListPlaylist.SelectedIndex + 1))

                For i = 1 To rpSelectedCount
                    sw.Write(ratingPlusSelected(i).Description)
                    sw.Write(vbTab & ratingPlusSelected(i).JPGFile)
                    sw.Write(vbTab & ratingPlusSelected(i).minRange & "," & ratingPlusSelected(i).maxRange)
                    sw.Write(vbTab & ratingPlusSelected(i).circleColourLeft.R & "," & ratingPlusSelected(i).circleColourLeft.G & "," & ratingPlusSelected(i).circleColourLeft.B)
                    sw.Write(vbTab & ratingPlusSelected(i).circleColourRight.R & "," & ratingPlusSelected(i).circleColourRight.G & "," & ratingPlusSelected(i).circleColourRight.B)
                    If ratingPlusSelected(i).neutralColour = True Then
                        sw.Write(vbTab & ratingPlusSelected(i).circleColourNeutral.R & "," & ratingPlusSelected(i).circleColourNeutral.G & "," & ratingPlusSelected(i).circleColourNeutral.B)
                    End If
                    'sw.WriteLine()
                    sw.WriteLine(vbTab & ratingPlusSelected(i).rated)
                Next
                sw.Close()
            Else
                'Do Nothing  ' rpSelectedCount
            End If
        End If

        Me.Close()  'close form
        FrmStartup.Show()  'go back to startup form

    End Sub


    Private Sub FrmCombined_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Me.KeyPress
        Select Case e.KeyChar
            Case ChrW(Keys.Escape)  'Close  
                Dim msgBoxResp As Integer
                Dim strSelectionSave As String
                Dim msgBox1 As Integer


                WMPcontrols1.pause()
                numMousePanelDown = numMousePanelDown + 1   'pause the video when decide whether to exit
                panelMouseDown = False

                msgBox1 = MsgBox("Are you sure to exit?", MsgBoxStyle.YesNo, "Exit")  'in case of press of the escape key by accident
                If msgBox1 = MsgBoxResult.Yes Then

                    gPanel.Dispose()
                    doubleBuffer.Graphics.Dispose()

                    'For plusOption, update rated list
                    If plusOption = plusOptionWithRatings Then
                        msgBoxResp = MsgBox("Update Plus Option rated data?", MsgBoxStyle.YesNo, "Plus Option")
                        If msgBoxResp = Microsoft.VisualBasic.MsgBoxResult.Yes Then
                            'Must write selected list out to a file
                            If strRatingPlusDataFile = "" Then
                                If FrmStartup.txtID.Text = "" Then
                                    strSelectionSave = InputBox("Enter name to save selection under: ")
                                Else
                                    strSelectionSave = FrmStartup.txtID.Text
                                End If
                                strRatingPlusDataFile = dataFolder & "\" & strSelectionSave & ".SLT"
                            End If
                            'Can only have got here with strRatingPlusDataFile already set
                            ' sw = New StreamWriter(dataFolder & "\" & strSelectionSave & ".SLT")
                            sw = New StreamWriter(strRatingPlusDataFile)
                            'sw.WriteLine(mediaFolder & "\" & Me.lbListPlaylist.SelectedItem.ToString)
                            sw.WriteLine(playlistItems(Me.lbListPlaylist.SelectedIndex + 1))

                            For i = 1 To rpSelectedCount
                                sw.Write(ratingPlusSelected(i).Description)
                                sw.Write(vbTab & ratingPlusSelected(i).JPGFile)
                                sw.Write(vbTab & ratingPlusSelected(i).minRange & "," & ratingPlusSelected(i).maxRange)
                                sw.Write(vbTab & ratingPlusSelected(i).circleColourLeft.R & "," & ratingPlusSelected(i).circleColourLeft.G & "," & ratingPlusSelected(i).circleColourLeft.B)
                                sw.Write(vbTab & ratingPlusSelected(i).circleColourRight.R & "," & ratingPlusSelected(i).circleColourRight.G & "," & ratingPlusSelected(i).circleColourRight.B)
                                If ratingPlusSelected(i).neutralColour = True Then
                                    sw.Write(vbTab & ratingPlusSelected(i).circleColourNeutral.R & "," & ratingPlusSelected(i).circleColourNeutral.G & "," & ratingPlusSelected(i).circleColourNeutral.B)
                                End If
                                'sw.WriteLine()
                                sw.WriteLine(vbTab & ratingPlusSelected(i).rated)
                            Next
                            sw.Close()
                        Else
                            'Do Nothing  ' rpSelectedCount
                        End If
                    End If



                    Me.Close()  'close form
                    FrmStartup.Show()  'go back to startup form
                    FrmStartup.btnQuit.PerformClick() ' automaticlly close the programme!
                    Cursor.Show()
                ElseIf WMPcontrols1.currentPosition <> 0 Then

                    WMPcontrols1.play()
                    panelMouseDown = True

                End If

            Case ChrW(Keys.D8) 'KEY 8 to show/hide the film list
                If Me.lblFilmPlayed.Visible = True Then
                    Me.lblFilmPlayed.Hide()
                Else
                    Me.lblFilmPlayed.Show()
                End If



            Case ChrW(Keys.D7) 'KEY 7 to go to the START SCREEN
                Dim filmList As String = ""
                For i As Integer = 1 To mediaCount
                    filmList = filmList & vbCrLf & i & ". " & IO.Path.GetFileNameWithoutExtension(playlistItems(i).item)
                Next
                If isReadyToStart = False Then
                    Me.Focus()
                    Me.btnQuit.Hide()
                    If clipselected = True And ratingSelected = True Then
                        Cursor.Hide()  'hide the mouse cursor on the screen
                        lblUserName.Hide()
                        Me.AxWMP.Hide()
                        Me.FormBorderStyle = Windows.Forms.FormBorderStyle.None
                        Me.WindowState = FormWindowState.Maximized
                        Me.AxWMP.uiMode = "none"
                        'Me.AxWMP.Location = New System.Drawing.Point(10, 10)
                        Me.AxWMP.Left = 10
                        Me.AxWMP.Top = 25
                        Me.AxWMP.Width = Me.Width - 20
                        Me.AxWMP.Height = Me.Height - 300
                        Me.AxWMP.stretchToFit = True
                        Me.btnQuit.Location = New Point(Me.Width * 0.9, Me.Height * 0.9)
                        Me.lblTime.Show()
                        Me.lblTime.Location = New Point(50, Me.Height - 251)
                        Me.lblTime.ForeColor = Color.AntiqueWhite
                        Me.lblFilmCounter.Show()
                        Me.lblFilmCounter.Location = New Point(50, Me.Height - 230)
                        Me.lblFilmCounter.ForeColor = Color.AntiqueWhite
                        'List of the films played, show when key 8 on the number pad is pressed
                        Me.lblFilmPlayed.Location = New Point(Me.Width - 525, Me.Height - 270)
                        Me.lblFilmPlayed.ForeColor = Color.AntiqueWhite
                        Me.lblFilmPlayed.Text = filmList


                        'Me.AxWMP.Width = 750
                        'Me.AxWMP.Height = 720

                        Me.MousePanel.Location = New System.Drawing.Point((Me.Width - 860) / 2, Me.AxWMP.Height + 30)
                        Me.BackColor = Color.Black
                        gbContent.Hide()
                        gbRatings.Hide()
                        lblInstructions.Hide()

                        Me.lblNotice.Text = "Please pull the " & vbCrLf & "TRIGGER" & vbCrLf & " to start rating"
                        Me.lblNotice.Left = (Me.Width - Me.lblNotice.Width) / 2
                        Me.lblNotice.Top = Me.AxWMP.Height / 3
                        Me.lblNotice.Show()


                        isReadyToStart = True


                    Else
                        Cursor.Show()
                        MsgBox("You must select both a clip and a rating to go to the START Screen")
                    End If
                End If

            Case ChrW(Keys.D5)
                    numMousePanelDown = numMousePanelDown + 1
                    Debug.Print(numMousePanelDown)
                    If numMousePanelDown Mod 2 = 1 Then
                        panelMouseDown = True
                    Else
                        panelMouseDown = False
                    End If

            Case ChrW(Keys.Space)  'START THE RATING
                    Debug.Print("space")
                    Me.Focus()
                    sbcount = sbcount + 1
                    If isEnd = False Then
                        If sbcount = 1 Then
                            If isReadyToStart = True Then

                                Me.AxWMP.uiMode = "none"
                                'Me.AxWMP.Location = New System.Drawing.Point(10, 10)
                                Me.AxWMP.Left = 10
                                Me.AxWMP.Top = 25
                                Me.AxWMP.Width = Me.Width - 20
                            Me.AxWMP.Height = Me.Height - 300
                            Me.AxWMP.stretchToFit = True
                            Me.AxWMP.Show()
                            lblNotice.Hide()
                            lblNotice.Text = "Please pull the " & vbCrLf & "TRIGGER" & vbCrLf & " to rate the next video"

                                lblFilmCounter.Text = "Film Counter: " & numFilmPlayed + 1 & "/" & mediaCount
                                RunRating()

                            Else
                                Cursor.Show()
                                MsgBox("You must select both a clip and a rating and go to the Start Screen")
                                sbcount = 0
                            End If

                        Else
                            If AxWMP.playState = WMPLib.WMPPlayState.wmppsPlaying Or AxWMP.playState = WMPLib.WMPPlayState.wmppsScanForward Or AxWMP.playState = WMPLib.WMPPlayState.wmppsScanReverse Then
                                WMPcontrols1.pause()
                                numMousePanelDown = numMousePanelDown + 1
                                panelMouseDown = False

                            ElseIf AxWMP.playState = WMPLib.WMPPlayState.wmppsPaused Then
                                WMPcontrols1.play()
                                panelMouseDown = True
                            End If

                        End If
                    Else
                        MsgBox("You have finished all the ratings, please contact the administrator")
                    End If
            Case ChrW(Keys.D1) ' 1 = play/stop
                    Me.Focus()
                    If AxWMP.playState = WMPLib.WMPPlayState.wmppsPlaying Or AxWMP.playState = WMPLib.WMPPlayState.wmppsScanForward Or AxWMP.playState = WMPLib.WMPPlayState.wmppsScanReverse Then
                        WMPcontrols1.stop()
                    Else
                        WMPcontrols1.play()
                    End If
            Case ChrW(Keys.D2)  '2 = pause/continue 
                    Me.Focus()
                    If AxWMP.playState = WMPLib.WMPPlayState.wmppsPlaying Or AxWMP.playState = WMPLib.WMPPlayState.wmppsScanForward Or AxWMP.playState = WMPLib.WMPPlayState.wmppsScanReverse Then
                        WMPcontrols1.pause()
                        numMousePanelDown = numMousePanelDown + 1
                        panelMouseDown = False

                    ElseIf AxWMP.playState = WMPLib.WMPPlayState.wmppsPaused Then
                        WMPcontrols1.play()
                    End If
            Case ChrW(Keys.D3)  '3 = rewind
                    Me.Focus()
                    WMPcontrols1.currentPosition = 0
                    '  Case ChrW(Keys.D4)  '5 = fast reverse
                    '      WMPcontrols1.fastReverse()
                    '  Case ChrW(Keys.D5) '6 = fast forward
                    '      WMPcontrols1.fastForward()

                    'Case ChrW(Keys.F2)  'toggle lower display
            Case ChrW(Keys.D)  'toggle lower display
                    Me.Focus()
                    If displayState = 0 Then 'it's minimal, so maximise
                        Me.Height = 700
                        displayState = 1
                    ElseIf displayState = 1 Then ' it's maximal, so minimise
                        Me.Height = 414
                        displayState = 0
                    End If
            Case Else
                    Me.Focus()
        End Select
        ' e.Handled = False  'MUST BE FALSE OTHERWISE WMP PICKS UP SBAR PRESS
    End Sub


    Private Sub lbListPlaylist_MouseDoubleClick(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles lbListPlaylist.MouseDoubleClick

        PlayMedia(Me.lbListPlaylist.SelectedIndex)

    End Sub


    '  Private Sub btnAddPlayList_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    'Feature Removed----------------------

    '   Dim myStream As Stream = Nothing
    '   Dim openFileDialog1 As New OpenFileDialog()


    ' 'Clear list box
    ' lbListPlaylist.Items.Clear()

    ' mediaCount = 0

    ' openFileDialog1.InitialDirectory = mediaFolder
    ' openFileDialog1.Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*"
    ' openFileDialog1.FilterIndex = 1
    ' 'openFileDialog1.Filter = "WMV files (*.wmv)|*.wmv|MPG files (*.mpg)|*.mpg|AVI files (*.avi)|*.avi|All files (*.*)|*.*"
    ' 'openFileDialog1.FilterIndex = 4
    '
    '        If openFileDialog1.ShowDialog() = System.Windows.Forms.DialogResult.OK Then
    '
    '        Try
    ' ' Create an instance of StreamReader to read from a file.
    ' Dim sr As StreamReader = New StreamReader(OpenFileDialog1.OpenFile())
    ' Dim line As String
    ' ' Read and display the lines from the file until the end of the file is reached.
    ' Do
    ' line = sr.ReadLine()
    ' If line <> "" Then
    ' mediaCount = mediaCount + 1
    ' playlistItems(mediaCount).item = line
    ' playlistItems(mediaCount).folder = Path.GetDirectoryName(OpenFileDialog1.FileName)  'path
    ' playlistItems(mediaCount).playCount = 0
    'playlistItems(mediaCount).dataCollected = False
    'Me.lbListPlaylist.Items.Add(CStr(playlistItems(mediaCount).item))
    ''   Me.lbListPlaylist.Items.Add(CStr(mediaCount) & vbTab & playlistItems(mediaCount).item)
    'End If
    'Loop Until line Is Nothing
    'sr.Close()
    ''mediaFolder = Path.GetDirectoryName(openFileDialog1.FileName)
    ''MsgBox(mediaFolder)
    'Catch Ex As Exception
    ' ' Let the user know what went wrong.
    'Console.WriteLine("The file could not be read: ")
    'Console.WriteLine(Ex.Message)
    'End Try
    '
    'End If
    '    End Sub



    Private Sub lbListPlaylist_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lbListPlaylist.SelectedIndexChanged

        'Debug.Print(Me.lbListPlaylist.SelectedIndex & " " & Me.lbListPlaylist.SelectedItem)

        If dontTriggerIndexChange = False Then

            'Load the clip
            Try

                'Me.AxWMP.URL = mediaFolder & "\" & Me.lbListPlaylist.SelectedItem.ToString
                Me.AxWMP.URL = playlistItems(Me.lbListPlaylist.SelectedIndex + 1).item  '+1 since zero based,  item is Path + filename 
                Do
                    Application.DoEvents()
                    'Debug.Print(Me.AxWMP.status & " " & Me.AxWMP.playState & " " & Me.AxWMP.Ctlcontrols.currentPosition)
                Loop Until Me.AxWMP.playState = WMPLib.WMPPlayState.wmppsPlaying '"Playing"
                WMPcontrols1.pause()
                WMPcontrols1.currentPosition = 0 'rewind to start
                clipselected = True
            Catch Ex As Exception
                MessageBox.Show("Cannot read file from disk. Original error: " & Ex.Message)
                clipselected = False
            End Try

        End If

    End Sub

    Private Sub btnMoveUp_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnMoveUp.Click
        Dim ii As Integer
        Dim arrayElement As Integer

        'Make sure our item is not the first one on the list.
        If Me.lbListPlaylist.SelectedIndex > 0 Then

            dontTriggerIndexChange = True
            ii = Me.lbListPlaylist.SelectedIndex - 1

            Me.lbListPlaylist.Items.Insert(ii, Me.lbListPlaylist.SelectedItem)
            Me.lbListPlaylist.Items.RemoveAt(Me.lbListPlaylist.SelectedIndex)
            Me.lbListPlaylist.SelectedIndex = ii

            dontTriggerIndexChange = False

            'SWAP ARRAY ELEMENTS TOO
            arrayElement = Me.lbListPlaylist.SelectedIndex + 1
            tempPlayListItem = playlistItems(arrayElement + 1)
            playlistItems(arrayElement + 1) = playlistItems(arrayElement)
            playlistItems(arrayElement) = tempPlayListItem

        End If

        Debug.Print("Move Up")
        For ii = 1 To mediaCount
            Debug.Print(playlistItems(ii).item)
        Next

    End Sub

    Private Sub btnMoveDown_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnMoveDown.Click

        Dim ii As Integer
        Dim arrayElement As Integer

        'Make sure our item is not the last one on the list.
        If Me.lbListPlaylist.SelectedIndex < Me.lbListPlaylist.Items.Count - 1 Then
            dontTriggerIndexChange = True
            'Insert places items above the index you supply, since we want
            'to move it down the list we have to do + 2
            ii = Me.lbListPlaylist.SelectedIndex + 2
            Me.lbListPlaylist.Items.Insert(ii, Me.lbListPlaylist.SelectedItem)
            Me.lbListPlaylist.Items.RemoveAt(Me.lbListPlaylist.SelectedIndex)
            Me.lbListPlaylist.SelectedIndex = ii - 1
            dontTriggerIndexChange = False

            'SWAP ARRAY ELEMENTS TOO
            arrayElement = Me.lbListPlaylist.SelectedIndex + 1
            tempPlayListItem = playlistItems(arrayElement)
            playlistItems(arrayElement) = playlistItems(arrayElement - 1)
            playlistItems(arrayElement - 1) = tempPlayListItem
        End If

        Debug.Print("Move Down")
        For ii = 1 To mediaCount
            Debug.Print(playlistItems(ii).item)
        Next

    End Sub

    Private Sub btnRemoveItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRemoveItem.Click

        Dim ii As Integer
        Dim arrayElement As Integer

        arrayElement = Me.lbListPlaylist.SelectedIndex + 1

        dontTriggerIndexChange = True
        Try
            Me.lbListPlaylist.Items.RemoveAt(Me.lbListPlaylist.SelectedIndex)
        Catch ex As Exception
            MsgBox("No item in the playlist is selected or the playlist is empty")

        End Try

        'Debug.Print(Me.lbListPlaylist.SelectedIndex & "After remove")
        dontTriggerIndexChange = False

        'Remove from array
        If arrayElement > 0 And arrayElement <> mediaCount Then

            'Debug.Print(arrayElement)
            For ii = arrayElement To mediaCount - 1
                playlistItems(ii) = playlistItems(ii + 1)
            Next
            mediaCount = mediaCount - 1
            'Debug.Print(mediaCount)
        ElseIf arrayElement = mediaCount Then
            playlistItems(arrayElement) = Nothing
            mediaCount = mediaCount - 1
        End If

    End Sub

    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
        dontTriggerIndexChange = True
        Me.lbListPlaylist.Items.Clear()
        dontTriggerIndexChange = False
        Me.AxWMP.URL = ""
        For i As Integer = 1 To mediaCount
            playlistItems(i) = Nothing
        Next

        'Reset array size to 0
        mediaCount = 0

    End Sub


    Private Sub btnAddItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAddItem.Click
        Dim filenames
        Dim filenameOnly As String
        OpenFileDialog1.InitialDirectory = mediaFolder
        'OpenFileDialog1.Filter = "WMV files (*.wmv)|*.wmv|MPG files (*.mpg)|*.mpg|AVI files (*.avi)|*.avi|MPEG4 files (*.mp4)|*.mp4|QT movie files (*.mov)|*.mov|All files (*.*)|*.*"
        OpenFileDialog1.Filter = "All Media files (*.*)|*.*"
        OpenFileDialog1.Multiselect = True
        OpenFileDialog1.FilterIndex = 1
        If OpenFileDialog1.ShowDialog() = System.Windows.Forms.DialogResult.OK Then
            'OpenFileDialog1.RestoreDirectory = True
            Try
                filenames = OpenFileDialog1.FileNames
                For Each fileName As String In filenames
                    Debug.Print(filenames)
                    filenameOnly = IO.Path.GetFileName(fileName)
                    Me.lbListPlaylist.Items.Add(filenameOnly)
                    mediaCount = mediaCount + 1
                    playlistItems(mediaCount).item = fileName
                    playlistItems(mediaCount).folder = Path.GetDirectoryName(OpenFileDialog1.FileName) 'path
                    playlistItems(mediaCount).playCount = 0
                    playlistItems(mediaCount).dataCollected = False
                Next
            Catch Ex As Exception
                ' Let the user know what went wrong.
                Console.WriteLine("The file could not be read: ")
                Console.WriteLine(Ex.Message)
            End Try
        End If

        'Dim FilePath As String = ""
        'Dim FileName As String

        'If OpenFileDialog1.ShowDialog() = System.Windows.Forms.DialogResult.OK Then

        '    FileOpen(1, OpenFileDialog1.FileName, OpenMode.Input)
        '    Do Until EOF(1) 'read the lines of the file .txt
        '        FilePath = LineInput(1) 'the path include the name of the file
        '        FileName = IO.Path.GetFileName(FilePath)
        '        Try
        '            mediaCount = mediaCount + 1
        '            'playlistItems(mediaCount).item = OpenFileDialog1.SafeFileName  'don't include path
        '            playlistItems(mediaCount).item = FilePath
        '            'playlistItems(mediaCount).folder = Path.GetDirectoryName(OpenFileDialog1.FileName)  'path
        '            playlistItems(mediaCount).folder = FilePath
        '            playlistItems(mediaCount).playCount = 0
        '            playlistItems(mediaCount).dataCollected = False

        '            dontTriggerIndexChange = True  'When you add something into the list, the SelectedIndex Change,but 
        '            ' this is not a change caused by the mouse click, so we don't trigger the change

        '            Me.lbListPlaylist.Items.Add(FileName)

        '            ' mediaFolder = Path.GetDirectoryName(OpenFileDialog1.FileName)
        '            'MsgBox(mediaFolder)
        '        Catch Ex As Exception
        '            ' Let the user know what went wrong.
        '            Console.WriteLine("The file could not be read: ")
        '            Console.WriteLine(Ex.Message)
        '        End Try
        '    Loop

        '    dontTriggerIndexChange = False


        'End If

    End Sub

    Private Sub lbRatings_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lbRatings.SelectedIndexChanged


        '  Dim myStream As Stream = Nothing
        '  Dim sr As StreamReader
        '  Dim line As String

        ''Local
        'Dim ratingCategory As String
        'Dim rgbValues(3) As String
        'Dim nFields As Integer

        'Dim delimStr As String = Chr(9) 'tab
        'Dim delimiter As Char() = delimStr.ToCharArray()
        '
        '       Dim lineNumber As Integer


        'plusOptionOff or plusOptionNoRatings - rating data loaded into ratingInfo
        'but different folders used:
        'for plusOptionOff use ratingsFolder
        'for plusOptionNoRatings use plusFolder
        If plusOption = plusOptionOff Or plusOption = plusOptionNoRatings Then
            'Get selected ratings info
            ratingImage = ratingInfo(Me.lbRatings.SelectedIndex + 1).JPG
            ratingDescription = ratingInfo(Me.lbRatings.SelectedIndex + 1).Description
            ratingJPG = ratingInfo(Me.lbRatings.SelectedIndex + 1).JPGFile
            minRange = ratingInfo(Me.lbRatings.SelectedIndex + 1).minRange
            maxRange = ratingInfo(Me.lbRatings.SelectedIndex + 1).maxRange
            coordRange = maxRange - minRange
            circleColour(1) = ratingInfo(Me.lbRatings.SelectedIndex + 1).circleColourLeft
            circleColour(2) = ratingInfo(Me.lbRatings.SelectedIndex + 1).circleColourRight
            neutralColour = ratingInfo(Me.lbRatings.SelectedIndex + 1).neutralColour
            If neutralColour = True Then
                circleColour(3) = ratingInfo(Me.lbRatings.SelectedIndex + 1).circleColourNeutral
            End If
        ElseIf plusOption = plusOptionWithRatings Then 'Using rating data in ratingPlusSelected and ratings from Plus\1234 subfolders
            ratingImage = ratingPlusSelected(Me.lbRatings.SelectedIndex + 1).JPG
            ratingDescription = ratingPlusSelected(Me.lbRatings.SelectedIndex + 1).Description
            ratingJPG = ratingPlusSelected(Me.lbRatings.SelectedIndex + 1).JPGFile
            minRange = ratingPlusSelected(Me.lbRatings.SelectedIndex + 1).minRange
            maxRange = ratingPlusSelected(Me.lbRatings.SelectedIndex + 1).maxRange
            coordRange = maxRange - minRange
            circleColour(1) = ratingPlusSelected(Me.lbRatings.SelectedIndex + 1).circleColourLeft
            circleColour(2) = ratingPlusSelected(Me.lbRatings.SelectedIndex + 1).circleColourRight
            neutralColour = ratingPlusSelected(Me.lbRatings.SelectedIndex + 1).neutralColour
            If neutralColour = True Then
                circleColour(3) = ratingPlusSelected(Me.lbRatings.SelectedIndex + 1).circleColourNeutral
            End If
        End If

        'Display selected rating
        Me.MousePanel.BackgroundImage = ratingImage
        Me.MousePanel.BackgroundImageLayout = ImageLayout.Center
        ratingSelected = True


        '        'Get files associated with listbox choice
        '        ratingFile = ratingsFolder & "\" & Me.lbRatings.SelectedItem.ToString & ".rtg"  'Get rtg filename
        '        sr = New StreamReader(ratingFile)
        '
        '        lineNumber = 0
        '        neutralColour = False
        '        Do
        ' line = sr.ReadLine()
        ' Debug.WriteLine(line & " " & Microsoft.VisualBasic.Len(line))
        ' If Microsoft.VisualBasic.Len(line) > 0 Then
        ' lineNumber = lineNumber + 1
        ' Select Case lineNumber
        '     Case 1
        ' ratingDescription = line
        '     Case 2
        ' ratingJPG = ratingsFolder & "\" & line
        '     Case 3
        ' rgbValues = Split(line, ",")
        ' Debug.Print(rgbValues(0) & rgbValues(1) & rgbValues(2))
        ' circleColour(1) = Color.FromArgb(255, CInt(rgbValues(0)), CInt(rgbValues(1)), CInt(rgbValues(2)))
        '     Case 4
        ' rgbValues = Split(line, ",")
        ' Debug.Print(rgbValues(0) & rgbValues(1) & rgbValues(2))
        ' circleColour(2) = Color.FromArgb(255, CInt(rgbValues(0)), CInt(rgbValues(1)), CInt(rgbValues(2)))
        '     Case 5  'if this line exists, it is the neutral colour
        ' rgbValues = Split(line, ",")
        ' Debug.Print(rgbValues(0) & rgbValues(1) & rgbValues(2))
        ' circleColour(3) = Color.FromArgb(255, CInt(rgbValues(0)), CInt(rgbValues(1)), CInt(rgbValues(2)))
        ' neutralColour = True
        ' End Select
        ' End If
        ' Loop While sr.Peek <> -1
        ' sr.Close()

        ''Display ratings image
        'RatingImage = Image.FromFile(ratingJPG)
        'Me.MousePanel.BackgroundImage = RatingImage
        'Me.MousePanel.BackgroundImageLayout = ImageLayout.None


        '    ratingJPG = ratingsFolder & "\" & Me.lbRatings.SelectedItem.ToString  'Get graphics filename first
        '   ratingFile = Microsoft.VisualBasic.Left(ratingJPG, Microsoft.VisualBasic.Len(ratingJPG) - 3) & "txt"  'Get txt filename
        '  If My.Computer.FileSystem.FileExists(ratingFile) Then
        ' Else
        'MsgBox("Ratings text file not found.")
        'Exit Sub
        'End If

    End Sub


    Private Sub MousePanel_Click(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles MousePanel.Click
        'numMousePanelDown = numMousePanelDown + 1
        'If numMousePanelDown Mod 2 = 1 Then
        'panelMouseDown = True
        ' Else
        'panelMouseDown = False
        'End If
    End Sub

    Private Sub MousePanel_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles MousePanel.MouseUp
        'panelMouseDown = True
    End Sub

    Private Sub AxWMP_StatusChange(ByVal sender As Object, ByVal e As System.EventArgs) Handles AxWMP.StatusChange

        ' play = False
        ' If AxWMP.playState = WMPLib.WMPPlayState.wmppsPlaying Then
        ' play = True
        ' End If

        If AxWMP.playState = WMPLib.WMPPlayState.wmppsStopped Then
            clipselected = False
        End If

    End Sub

    Private Sub btnTempDraw_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTempDraw.Click

        Dim gbm As Graphics
        'Do an initial clear of the buffer

        Me.MousePanel.BackgroundImage = Nothing

        'gPanel.Clear(Color.White)
        'gPanel.DrawRectangle(blackPen, rectangleLeft, rectangleTop, rectangleWidth, rectangleHeight)

        Dim bm = New Bitmap(Me.MousePanel.Width, Me.MousePanel.Height)
        gbm = Graphics.FromImage(bm)

        gbm.Clear(Color.White)
        gbm.DrawRectangle(blackPen, rectangleLeft, rectangleTop, rectangleWidth, rectangleHeight)
        bm.Save(mediaFolder & "\template.jpg")
        gbm.Dispose()
        bm.Dispose()

    End Sub

    Private Sub cbRunAsPlayList_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cbRunAsPlayList.CheckedChanged

        If Me.cbRunAsPlayList.Checked = True Then
            If plusOption <> plusOptionOff Then
                MsgBox("Cannot create play list if Plus option is selected")
                Me.cbRunAsPlayList.Checked = False
                Exit Sub
            End If

        End If
    End Sub

    Public Sub New()

        ' This call is required by the designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.

    End Sub

    Private Sub FrmCombined_MaximizedBoundsChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.MaximizedBoundsChanged

    End Sub

    Private Sub lblHeader_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lblHeader.Click

    End Sub

    'this button is deleted
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim filenames
        Dim INT As Integer
        For INT = 1 To 3
            filenames = My.Computer.FileSystem.GetFiles("C:\Users\Super\Desktop\Media\Learning_Data\L" & CType(INT, String) & "\", FileIO.SearchOption.SearchTopLevelOnly, "*.*")
            FileOpen(1, "C:\Users\Super\Desktop\L" & CType(INT, String) & ".txt", OpenMode.Output)
            For Each fileName As String In filenames
                PrintLine(1, fileName)
            Next
            FileClose(1)
        Next
    End Sub

    Private Sub MousePanel_Paint(ByVal sender As System.Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles MousePanel.Paint

    End Sub

    Private Sub Button1_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim templist(mediaCount) As Integer
        Dim numBigger(mediaCount) As Integer
       
        Dim steps As Integer

        templist = randomArr(mediaCount)
        For h As Integer = 0 To mediaCount - 1 'initialise
            numBigger(h) = 0
        Next


        For a As Integer = 1 To mediaCount
            For b As Integer = 0 To a - 1
                If templist(b) > templist(a) Then
                    numBigger(a) = numBigger(a) + 1
                End If
            Next
        Next
        For i As Integer = 0 To mediaCount - 1
            Console.Write(templist(i))
        Next
        Console.WriteLine()
        For i As Integer = 0 To mediaCount - 1
            Console.Write(numBigger(i))
        Next


        dontTriggerIndexChange = True

        For i As Integer = 0 To mediaCount - 2
            dontTriggerIndexChange = True
            Me.lbListPlaylist.SelectedIndex = templist(i) + numBigger(i) - 1 'find the video in the playlist
            dontTriggerIndexChange = False

            steps = Me.lbListPlaylist.SelectedIndex - i

            For j As Integer = 1 To steps
                moveUp()
            Next
        Next
        dontTriggerIndexChange = False

        Me.lbListPlaylist.SelectedIndex = 0 'at the end of the random process, always select the first item in the list




    End Sub

    Private Sub Label1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lblStartAt.Click

    End Sub

    Private Sub TextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tbStartTime.TextChanged

    End Sub
End Class