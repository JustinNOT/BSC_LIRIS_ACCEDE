﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmStartup
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmStartup))
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.btnStart = New System.Windows.Forms.Button()
        Me.btnQuit = New System.Windows.Forms.Button()
        Me.SaveFileDialog1 = New System.Windows.Forms.SaveFileDialog()
        Me.FolderBrowserDialog1 = New System.Windows.Forms.FolderBrowserDialog()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.gbTracePlus = New System.Windows.Forms.GroupBox()
        Me.btnLoadPreSelected = New System.Windows.Forms.Button()
        Me.cbPlusOption = New System.Windows.Forms.CheckBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.lblID = New System.Windows.Forms.Label()
        Me.txtID = New System.Windows.Forms.TextBox()
        Me.chkSaveData = New System.Windows.Forms.CheckBox()
        Me.gbTracePlus.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'lblTitle
        '
        Me.lblTitle.Font = New System.Drawing.Font("Cambria", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTitle.Location = New System.Drawing.Point(12, 25)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.Size = New System.Drawing.Size(393, 84)
        Me.lblTitle.TabIndex = 0
        Me.lblTitle.Text = "GTrace" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "School of Psychology " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Queen's University Belfast"
        Me.lblTitle.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'btnStart
        '
        Me.btnStart.Font = New System.Drawing.Font("Cambria", 9.75!)
        Me.btnStart.Location = New System.Drawing.Point(108, 409)
        Me.btnStart.Name = "btnStart"
        Me.btnStart.Size = New System.Drawing.Size(85, 35)
        Me.btnStart.TabIndex = 3
        Me.btnStart.Text = "Continue"
        Me.btnStart.UseVisualStyleBackColor = True
        '
        'btnQuit
        '
        Me.btnQuit.Font = New System.Drawing.Font("Cambria", 9.75!)
        Me.btnQuit.Location = New System.Drawing.Point(208, 409)
        Me.btnQuit.Name = "btnQuit"
        Me.btnQuit.Size = New System.Drawing.Size(85, 35)
        Me.btnQuit.TabIndex = 4
        Me.btnQuit.Text = "Exit"
        Me.btnQuit.UseVisualStyleBackColor = True
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'gbTracePlus
        '
        Me.gbTracePlus.Controls.Add(Me.btnLoadPreSelected)
        Me.gbTracePlus.Controls.Add(Me.cbPlusOption)
        Me.gbTracePlus.Font = New System.Drawing.Font("Cambria", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gbTracePlus.Location = New System.Drawing.Point(97, 248)
        Me.gbTracePlus.Name = "gbTracePlus"
        Me.gbTracePlus.Size = New System.Drawing.Size(220, 130)
        Me.gbTracePlus.TabIndex = 14
        Me.gbTracePlus.TabStop = False
        Me.gbTracePlus.Text = "TracePlus"
        '
        'btnLoadPreSelected
        '
        Me.btnLoadPreSelected.Location = New System.Drawing.Point(65, 59)
        Me.btnLoadPreSelected.Name = "btnLoadPreSelected"
        Me.btnLoadPreSelected.Size = New System.Drawing.Size(90, 47)
        Me.btnLoadPreSelected.TabIndex = 1
        Me.btnLoadPreSelected.Text = "Load Pre-selected ratings"
        Me.btnLoadPreSelected.UseVisualStyleBackColor = True
        '
        'cbPlusOption
        '
        Me.cbPlusOption.AutoSize = True
        Me.cbPlusOption.Location = New System.Drawing.Point(15, 19)
        Me.cbPlusOption.Name = "cbPlusOption"
        Me.cbPlusOption.Size = New System.Drawing.Size(108, 18)
        Me.cbPlusOption.TabIndex = 0
        Me.cbPlusOption.Text = "Run Plus option"
        Me.cbPlusOption.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.lblID)
        Me.GroupBox1.Controls.Add(Me.txtID)
        Me.GroupBox1.Controls.Add(Me.chkSaveData)
        Me.GroupBox1.Font = New System.Drawing.Font("Cambria", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(97, 127)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(220, 99)
        Me.GroupBox1.TabIndex = 15
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Data"
        '
        'lblID
        '
        Me.lblID.AutoSize = True
        Me.lblID.Location = New System.Drawing.Point(12, 42)
        Me.lblID.Name = "lblID"
        Me.lblID.Size = New System.Drawing.Size(56, 14)
        Me.lblID.TabIndex = 10
        Me.lblID.Text = "Identifier"
        '
        'txtID
        '
        Me.txtID.Location = New System.Drawing.Point(15, 60)
        Me.txtID.Name = "txtID"
        Me.txtID.Size = New System.Drawing.Size(197, 22)
        Me.txtID.TabIndex = 9
        '
        'chkSaveData
        '
        Me.chkSaveData.AutoSize = True
        Me.chkSaveData.Checked = True
        Me.chkSaveData.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkSaveData.Location = New System.Drawing.Point(15, 19)
        Me.chkSaveData.Name = "chkSaveData"
        Me.chkSaveData.Size = New System.Drawing.Size(77, 18)
        Me.chkSaveData.TabIndex = 8
        Me.chkSaveData.Text = "Save Data"
        Me.chkSaveData.UseVisualStyleBackColor = True
        '
        'FrmStartup
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(418, 492)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.gbTracePlus)
        Me.Controls.Add(Me.btnQuit)
        Me.Controls.Add(Me.btnStart)
        Me.Controls.Add(Me.lblTitle)
        Me.Font = New System.Drawing.Font("Cambria", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "FrmStartup"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "GTrace"
        Me.gbTracePlus.ResumeLayout(False)
        Me.gbTracePlus.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents lblTitle As System.Windows.Forms.Label
    Friend WithEvents btnStart As System.Windows.Forms.Button
    Friend WithEvents btnQuit As System.Windows.Forms.Button
    Friend WithEvents SaveFileDialog1 As System.Windows.Forms.SaveFileDialog
    Friend WithEvents FolderBrowserDialog1 As System.Windows.Forms.FolderBrowserDialog
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents gbTracePlus As System.Windows.Forms.GroupBox
    Friend WithEvents cbPlusOption As System.Windows.Forms.CheckBox
    Friend WithEvents btnLoadPreSelected As System.Windows.Forms.Button
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents lblID As System.Windows.Forms.Label
    Friend WithEvents txtID As System.Windows.Forms.TextBox
    Friend WithEvents chkSaveData As System.Windows.Forms.CheckBox
End Class
