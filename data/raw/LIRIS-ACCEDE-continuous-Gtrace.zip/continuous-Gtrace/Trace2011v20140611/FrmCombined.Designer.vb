﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmCombined
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmCombined))
        Me.AxWMP = New AxWMPLib.AxWindowsMediaPlayer()
        Me.lblInstructions = New System.Windows.Forms.Label()
        Me.btnQuit = New System.Windows.Forms.Button()
        Me.MousePanel = New System.Windows.Forms.Panel()
        Me.lblHeader = New System.Windows.Forms.Label()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.gbContent = New System.Windows.Forms.GroupBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.cbRunAsPlayList = New System.Windows.Forms.CheckBox()
        Me.btnMoveDown = New System.Windows.Forms.Button()
        Me.btnMoveUp = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnRemoveItem = New System.Windows.Forms.Button()
        Me.btnAddItem = New System.Windows.Forms.Button()
        Me.lbListPlaylist = New System.Windows.Forms.ListBox()
        Me.gbRatings = New System.Windows.Forms.GroupBox()
        Me.lbRatings = New System.Windows.Forms.ListBox()
        Me.btnTempDraw = New System.Windows.Forms.Button()
        Me.lblTime = New System.Windows.Forms.Label()
        Me.lblNotice = New System.Windows.Forms.Label()
        Me.lblVideoName = New System.Windows.Forms.Label()
        Me.lblUserName = New System.Windows.Forms.Label()
        Me.lblFilmCounter = New System.Windows.Forms.Label()
        Me.lblFilmPlayed = New System.Windows.Forms.Label()
        Me.lblStartAt = New System.Windows.Forms.Label()
        Me.tbStartTime = New System.Windows.Forms.TextBox()
        Me.lblStartAtTime = New System.Windows.Forms.Label()
        CType(Me.AxWMP, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MousePanel.SuspendLayout()
        Me.gbContent.SuspendLayout()
        Me.gbRatings.SuspendLayout()
        Me.SuspendLayout()
        '
        'AxWMP
        '
        Me.AxWMP.Enabled = True
        Me.AxWMP.Location = New System.Drawing.Point(3, 3)
        Me.AxWMP.Name = "AxWMP"
        Me.AxWMP.OcxState = CType(resources.GetObject("AxWMP.OcxState"), System.Windows.Forms.AxHost.State)
        Me.AxWMP.Size = New System.Drawing.Size(362, 306)
        Me.AxWMP.TabIndex = 0
        '
        'lblInstructions
        '
        Me.lblInstructions.Font = New System.Drawing.Font("Cambria", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblInstructions.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.lblInstructions.Location = New System.Drawing.Point(677, 344)
        Me.lblInstructions.Name = "lblInstructions"
        Me.lblInstructions.Size = New System.Drawing.Size(554, 265)
        Me.lblInstructions.TabIndex = 2
        Me.lblInstructions.Text = resources.GetString("lblInstructions.Text")
        '
        'btnQuit
        '
        Me.btnQuit.Font = New System.Drawing.Font("Cambria", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnQuit.Location = New System.Drawing.Point(1149, 615)
        Me.btnQuit.Name = "btnQuit"
        Me.btnQuit.Size = New System.Drawing.Size(93, 33)
        Me.btnQuit.TabIndex = 3
        Me.btnQuit.Text = "Close"
        Me.btnQuit.UseVisualStyleBackColor = True
        '
        'MousePanel
        '
        Me.MousePanel.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.MousePanel.Controls.Add(Me.lblHeader)
        Me.MousePanel.Location = New System.Drawing.Point(371, 38)
        Me.MousePanel.Name = "MousePanel"
        Me.MousePanel.Size = New System.Drawing.Size(860, 240)
        Me.MousePanel.TabIndex = 4
        '
        'lblHeader
        '
        Me.lblHeader.Location = New System.Drawing.Point(4, 5)
        Me.lblHeader.Name = "lblHeader"
        Me.lblHeader.Size = New System.Drawing.Size(561, 45)
        Me.lblHeader.TabIndex = 0
        Me.lblHeader.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblHeader.Visible = False
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'gbContent
        '
        Me.gbContent.Controls.Add(Me.lblStartAtTime)
        Me.gbContent.Controls.Add(Me.tbStartTime)
        Me.gbContent.Controls.Add(Me.lblStartAt)
        Me.gbContent.Controls.Add(Me.Button1)
        Me.gbContent.Controls.Add(Me.cbRunAsPlayList)
        Me.gbContent.Controls.Add(Me.btnMoveDown)
        Me.gbContent.Controls.Add(Me.btnMoveUp)
        Me.gbContent.Controls.Add(Me.btnClear)
        Me.gbContent.Controls.Add(Me.btnRemoveItem)
        Me.gbContent.Controls.Add(Me.btnAddItem)
        Me.gbContent.Controls.Add(Me.lbListPlaylist)
        Me.gbContent.Font = New System.Drawing.Font("Cambria", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gbContent.Location = New System.Drawing.Point(22, 354)
        Me.gbContent.Name = "gbContent"
        Me.gbContent.Size = New System.Drawing.Size(371, 258)
        Me.gbContent.TabIndex = 10
        Me.gbContent.TabStop = False
        Me.gbContent.Text = "Media"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(165, 202)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 35)
        Me.Button1.TabIndex = 18
        Me.Button1.Text = "Random"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'cbRunAsPlayList
        '
        Me.cbRunAsPlayList.AutoSize = True
        Me.cbRunAsPlayList.Checked = True
        Me.cbRunAsPlayList.CheckState = System.Windows.Forms.CheckState.Checked
        Me.cbRunAsPlayList.Location = New System.Drawing.Point(31, 201)
        Me.cbRunAsPlayList.Name = "cbRunAsPlayList"
        Me.cbRunAsPlayList.Size = New System.Drawing.Size(105, 18)
        Me.cbRunAsPlayList.TabIndex = 17
        Me.cbRunAsPlayList.Text = "Run As PlayList"
        Me.cbRunAsPlayList.UseVisualStyleBackColor = True
        '
        'btnMoveDown
        '
        Me.btnMoveDown.Location = New System.Drawing.Point(260, 58)
        Me.btnMoveDown.Name = "btnMoveDown"
        Me.btnMoveDown.Size = New System.Drawing.Size(93, 33)
        Me.btnMoveDown.TabIndex = 16
        Me.btnMoveDown.Text = "Move Down"
        Me.btnMoveDown.UseVisualStyleBackColor = True
        '
        'btnMoveUp
        '
        Me.btnMoveUp.Location = New System.Drawing.Point(260, 19)
        Me.btnMoveUp.Name = "btnMoveUp"
        Me.btnMoveUp.Size = New System.Drawing.Size(93, 33)
        Me.btnMoveUp.TabIndex = 15
        Me.btnMoveUp.Text = "Move Up"
        Me.btnMoveUp.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(260, 203)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(93, 33)
        Me.btnClear.TabIndex = 14
        Me.btnClear.Text = "Clear All"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnRemoveItem
        '
        Me.btnRemoveItem.Location = New System.Drawing.Point(260, 150)
        Me.btnRemoveItem.Name = "btnRemoveItem"
        Me.btnRemoveItem.Size = New System.Drawing.Size(93, 33)
        Me.btnRemoveItem.TabIndex = 13
        Me.btnRemoveItem.Text = "Remove Item"
        Me.btnRemoveItem.UseVisualStyleBackColor = True
        '
        'btnAddItem
        '
        Me.btnAddItem.Location = New System.Drawing.Point(260, 111)
        Me.btnAddItem.Name = "btnAddItem"
        Me.btnAddItem.Size = New System.Drawing.Size(93, 33)
        Me.btnAddItem.TabIndex = 11
        Me.btnAddItem.Text = "Add Item"
        Me.btnAddItem.UseVisualStyleBackColor = True
        '
        'lbListPlaylist
        '
        Me.lbListPlaylist.FormattingEnabled = True
        Me.lbListPlaylist.ItemHeight = 14
        Me.lbListPlaylist.Location = New System.Drawing.Point(15, 22)
        Me.lbListPlaylist.Name = "lbListPlaylist"
        Me.lbListPlaylist.Size = New System.Drawing.Size(225, 144)
        Me.lbListPlaylist.TabIndex = 10
        '
        'gbRatings
        '
        Me.gbRatings.Controls.Add(Me.lbRatings)
        Me.gbRatings.Font = New System.Drawing.Font("Cambria", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gbRatings.Location = New System.Drawing.Point(449, 354)
        Me.gbRatings.Name = "gbRatings"
        Me.gbRatings.Size = New System.Drawing.Size(207, 258)
        Me.gbRatings.TabIndex = 11
        Me.gbRatings.TabStop = False
        Me.gbRatings.Text = "Ratings"
        '
        'lbRatings
        '
        Me.lbRatings.FormattingEnabled = True
        Me.lbRatings.ItemHeight = 14
        Me.lbRatings.Location = New System.Drawing.Point(15, 22)
        Me.lbRatings.Name = "lbRatings"
        Me.lbRatings.Size = New System.Drawing.Size(163, 144)
        Me.lbRatings.TabIndex = 11
        '
        'btnTempDraw
        '
        Me.btnTempDraw.Font = New System.Drawing.Font("Cambria", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnTempDraw.Location = New System.Drawing.Point(1161, 576)
        Me.btnTempDraw.Name = "btnTempDraw"
        Me.btnTempDraw.Size = New System.Drawing.Size(70, 33)
        Me.btnTempDraw.TabIndex = 12
        Me.btnTempDraw.Text = "tempdraw"
        Me.btnTempDraw.UseVisualStyleBackColor = True
        Me.btnTempDraw.Visible = False
        '
        'lblTime
        '
        Me.lblTime.AutoSize = True
        Me.lblTime.Location = New System.Drawing.Point(740, 9)
        Me.lblTime.Name = "lblTime"
        Me.lblTime.Size = New System.Drawing.Size(0, 13)
        Me.lblTime.TabIndex = 13
        Me.lblTime.Visible = False
        '
        'lblNotice
        '
        Me.lblNotice.AutoSize = True
        Me.lblNotice.BackColor = System.Drawing.Color.Black
        Me.lblNotice.Font = New System.Drawing.Font("Microsoft Sans Serif", 48.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblNotice.ForeColor = System.Drawing.Color.White
        Me.lblNotice.Location = New System.Drawing.Point(154, 281)
        Me.lblNotice.Name = "lblNotice"
        Me.lblNotice.Size = New System.Drawing.Size(631, 219)
        Me.lblNotice.TabIndex = 14
        Me.lblNotice.Text = "Please pull the " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "TRIGGER " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "to rate the next video"
        Me.lblNotice.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblNotice.Visible = False
        '
        'lblVideoName
        '
        Me.lblVideoName.AutoSize = True
        Me.lblVideoName.BackColor = System.Drawing.Color.Black
        Me.lblVideoName.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblVideoName.ForeColor = System.Drawing.Color.White
        Me.lblVideoName.Location = New System.Drawing.Point(446, 9)
        Me.lblVideoName.Name = "lblVideoName"
        Me.lblVideoName.Size = New System.Drawing.Size(49, 16)
        Me.lblVideoName.TabIndex = 15
        Me.lblVideoName.Text = "Label1"
        Me.lblVideoName.Visible = False
        '
        'lblUserName
        '
        Me.lblUserName.AutoSize = True
        Me.lblUserName.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblUserName.ForeColor = System.Drawing.Color.Blue
        Me.lblUserName.Location = New System.Drawing.Point(18, 322)
        Me.lblUserName.Name = "lblUserName"
        Me.lblUserName.Size = New System.Drawing.Size(63, 20)
        Me.lblUserName.TabIndex = 16
        Me.lblUserName.Text = "Label1"
        '
        'lblFilmCounter
        '
        Me.lblFilmCounter.AutoSize = True
        Me.lblFilmCounter.Location = New System.Drawing.Point(544, 19)
        Me.lblFilmCounter.Name = "lblFilmCounter"
        Me.lblFilmCounter.Size = New System.Drawing.Size(0, 13)
        Me.lblFilmCounter.TabIndex = 17
        Me.lblFilmCounter.Visible = False
        '
        'lblFilmPlayed
        '
        Me.lblFilmPlayed.AutoSize = True
        Me.lblFilmPlayed.Location = New System.Drawing.Point(926, 320)
        Me.lblFilmPlayed.Name = "lblFilmPlayed"
        Me.lblFilmPlayed.Size = New System.Drawing.Size(0, 13)
        Me.lblFilmPlayed.TabIndex = 18
        Me.lblFilmPlayed.Visible = False
        '
        'lblStartAt
        '
        Me.lblStartAt.AutoSize = True
        Me.lblStartAt.Location = New System.Drawing.Point(28, 177)
        Me.lblStartAt.Name = "lblStartAt"
        Me.lblStartAt.Size = New System.Drawing.Size(45, 14)
        Me.lblStartAt.TabIndex = 19
        Me.lblStartAt.Text = "Start at"
        '
        'tbStartTime
        '
        Me.tbStartTime.Location = New System.Drawing.Point(73, 173)
        Me.tbStartTime.Name = "tbStartTime"
        Me.tbStartTime.Size = New System.Drawing.Size(69, 22)
        Me.tbStartTime.TabIndex = 20
        Me.tbStartTime.Text = "0"
        '
        'lblStartAtTime
        '
        Me.lblStartAtTime.AutoSize = True
        Me.lblStartAtTime.Location = New System.Drawing.Point(142, 177)
        Me.lblStartAtTime.Name = "lblStartAtTime"
        Me.lblStartAtTime.Size = New System.Drawing.Size(58, 14)
        Me.lblStartAtTime.TabIndex = 19
        Me.lblStartAtTime.Text = "second(s)"
        '
        'FrmCombined
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(1254, 676)
        Me.Controls.Add(Me.lblFilmPlayed)
        Me.Controls.Add(Me.lblFilmCounter)
        Me.Controls.Add(Me.lblUserName)
        Me.Controls.Add(Me.lblVideoName)
        Me.Controls.Add(Me.lblTime)
        Me.Controls.Add(Me.btnTempDraw)
        Me.Controls.Add(Me.gbRatings)
        Me.Controls.Add(Me.gbContent)
        Me.Controls.Add(Me.MousePanel)
        Me.Controls.Add(Me.btnQuit)
        Me.Controls.Add(Me.lblInstructions)
        Me.Controls.Add(Me.AxWMP)
        Me.Controls.Add(Me.lblNotice)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.KeyPreview = True
        Me.Name = "FrmCombined"
        Me.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "GTrace"
        CType(Me.AxWMP, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MousePanel.ResumeLayout(False)
        Me.gbContent.ResumeLayout(False)
        Me.gbContent.PerformLayout()
        Me.gbRatings.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents AxWMP As AxWMPLib.AxWindowsMediaPlayer
    Friend WithEvents lblInstructions As System.Windows.Forms.Label
    Friend WithEvents btnQuit As System.Windows.Forms.Button
    Friend WithEvents MousePanel As System.Windows.Forms.Panel
    Friend WithEvents lblHeader As System.Windows.Forms.Label
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents gbContent As System.Windows.Forms.GroupBox
    Friend WithEvents btnAddItem As System.Windows.Forms.Button
    Friend WithEvents lbListPlaylist As System.Windows.Forms.ListBox
    Friend WithEvents gbRatings As System.Windows.Forms.GroupBox
    Friend WithEvents btnTempDraw As System.Windows.Forms.Button
    Friend WithEvents btnRemoveItem As System.Windows.Forms.Button
    Friend WithEvents lbRatings As System.Windows.Forms.ListBox
    Friend WithEvents btnClear As System.Windows.Forms.Button
    Friend WithEvents btnMoveDown As System.Windows.Forms.Button
    Friend WithEvents btnMoveUp As System.Windows.Forms.Button
    Friend WithEvents cbRunAsPlayList As System.Windows.Forms.CheckBox
    Friend WithEvents lblTime As System.Windows.Forms.Label
    Friend WithEvents lblNotice As System.Windows.Forms.Label
    Friend WithEvents lblVideoName As System.Windows.Forms.Label
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents lblUserName As System.Windows.Forms.Label
    Friend WithEvents lblFilmCounter As System.Windows.Forms.Label
    Friend WithEvents lblFilmPlayed As System.Windows.Forms.Label
    Friend WithEvents lblStartAt As System.Windows.Forms.Label
    Friend WithEvents lblStartAtTime As System.Windows.Forms.Label
    Friend WithEvents tbStartTime As System.Windows.Forms.TextBox
End Class
